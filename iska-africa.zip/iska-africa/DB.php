<?php

class DB extends PDO
{
    private $driver='mysql';
    private $host='localhost';
    private $username='root';
    private $password='';
    private $database='iska-africa';
    private $db;

    public function __construct($driver= null, $host= null ,$username= null,$password= null,$database= null)
    {   
        if($host != null) {
            $this->driver=$driver;
            $this->host=$host;
            $this->username=$username;
            $this->password=$password;
            $this->database=$database;
        }
        try{
            $db = new PDO($this->driver.':dbname='.$this->database.';port=3306;host='.$this->host,$this->username,
            $this->password);
            $this->db= $db;
        }catch(PDOException $e){
            die('<h1>Impossible de se conncecter à la base de donnée</h1>'.$e->getMessage()); 
        }
    }
    
    public function query(string $query, $data=array())
    {
        try 
        {
            $requete = $this->db->prepare($query);
            $requete->execute($data);
            $resultat = $requete->fetchAll();            
        } catch (PDOException $E) {
            die('<h1>Impssible de se connecter a la base de donnee depuis la methode query</h1>'.$E->getMessage());
        }
        return $resultat;
    }

    // methode de tri dans l'ordre décroissant (Z -> A)
    public function tri( string $champ , array $table) 
    {
        $temp1 = 0;
        $temp2 =0;
        $max = count($table) -1;    
        $exch = false;        
        for ($i = 0; (($i< $max-1)); $i++)
        {    		
            for ($j= 0;($j < ($max-$i)); $j++)
            {
                if ($table[$j][$champ]<$table[$j+1][$champ] ){
                    $temp1 = $table[$j+1];
                    $table[$j+1] = $table[$j];
                    $table[$j]= $temp1;
                    $exch =true;
                }
            }            
        } 
        return $table;

    }
 

    // la methode top_tendance renvoie les tendances
    public function top_tendance()
    {
        $tendance = $this->query(
            'SELECT category.id as idCat,
                    category.name As cat, 
                    sous_category.name AS sous_cat, 
                    product.id AS id,
                    product.name AS prod, 
                    product.image AS img, 
                    product.price AS prix 
            FROM `product`,category,sous_category 
            WHERE category.id = product.category 
            AND sous_category.id = product.sous_category'
        );
        return $tendance;
    }
    
    //  la methode section_promo prend en parametre les id categories
    // et re
    public function section_promo($id1,$id2,$id3)
    {
        $cat_promo[0] = $this->query('SELECT * FROM `product` , category WHERE category.id =product.category and product.status = 1 and category.id='.$id1);  
        $cat_promo[1] = $this->query('SELECT * FROM `product` , category WHERE category.id =product.category and product.status = 1 and category.id='.$id2);  
        $cat_promo[2] = $this->query('SELECT * FROM `product` , category WHERE category.id =product.category and product.status = 1 and category.id='.$id3);       
        return $cat_promo;
    }

    // tous les produits pour une categorie donnée
    public function product_by_Category()
    {
        try 
        {
            $req = $this->db->prepare(
                "SELECT category.id As idCat, 
                        category.name As cat, 
                        sous_category.name AS sous_cat, 
                        product.id AS id ,
                        product.name AS prod, 
                        product.image AS img, 
                        product.price AS prix ,
                        product.description AS descri ,
                        product.stock AS stock 
                FROM `product`,category,sous_category 
                WHERE category.id = product.category 
                AND sous_category.id = product.sous_category
                AND category.id = :id"
            );
            $req->execute([
                'id' => $_GET['id']
            ]);
            $produit = $req->fetchAll();            
        } catch (PDOException $E) {
            die('<h1>Impssible de se connecter a la base de donnee depuis la methode query</h1>'.$E->getMessage());
        }
        
        return $produit;
    }

    //affichage des informations d'un produit grace à son 'Id'
    public function displayProduit()
    {
        try 
        {
            $req = $this->db->prepare(
                "SELECT category.id As idCat, 
                        category.name As cat, 
                        sous_category.name AS sous_cat, 
                        product.id AS id ,
                        product.name AS prod, 
                        product.image AS img, 
                        product.price AS prix ,
                        product.description AS descri ,
                        product.stock AS stock 
                FROM `product`,category,sous_category 
                WHERE category.id = product.category 
                AND sous_category.id = product.sous_category
                AND product.id = :id"
            );
            $req->execute([
                'id' => $_GET['id']
            ]);
            $produit = $req->fetchAll();            
        } catch (PDOException $E) {
            die('<h1>Impssible de se connecter a la base de donnee depuis la methode displayProduct</h1>'.$E->getMessage());
        }
        
        return $produit;
    } 

    public function name_category($id)
    {
        $category = $this->query('SELECT name FROM  category WHERE id='.$id);
        return $category;
    }

    public function rechercher($mot)
    {   
    
        $nbr = 0;        
        $tables = [
            'product',
            'category' ,
            'sous_category'
        ];
        foreach($tables as $k=> $table){            
            $search[$k] = $this->query("SELECT * FROM  $table WHERE name LIKE '%$mot%'  ");
        }

        for($i=0; $i< count($tables); $i++){                        
            if(isset($search[$i])){                
                for($j=0; $j< count($search[$i]); $j++){                    
                    if($search[$i][$j]['name']){                        
                        $nbr++;
                    }
                }
            }
        } 
        $search['3'] = $nbr;
          
        return $search;   
    }

    // public function inscription($nom, $prenom, $email, $nomb, $typeclt, $mdp)
    // {
    //     $mdp= password_hash($mdp, PASSWORD_DEFAULT);
    //     $save = $this->query("INSERT INTO `client` (`id`, `nom`, `prenom`, `nom_boutique`, `pays`, `email`, `statut`, `tel`, `password`, `avatar`)
    //         VALUES (NULL, :nom, :prenom, :nomb, NULL, :email , :typeclt, NULL, :mdp, '')",
    //         [
    //             'nom' => htmlentities($nom), 
    //             'prenom' => htmlentities($prenom),
    //             'email' => htmlentities($email), 
    //             'nomb' => htmlentities($nomb), 
    //             'typeclt' => htmlentities($typeclt), 
    //             'mdp' => htmlentities($mdp)
    //         ]
    //     );        
    // }
    
    public function valid()
    {
        # code...
        
            return $this->login();
        
    }

    public function verification($logEmail,$logPassword)
    {
        # code...
        $users = $this->query('SELECT id, email, password FROM client'); 
        foreach($users as $k => $user){
            if($logEmail === $users[$k]['email'] && $logPassword === $users[$k]['password']){        
               return true;
            }
        }
    }
    
    

    


}