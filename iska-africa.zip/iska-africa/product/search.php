<?php
session_start();
require_once '../elements/_header.php'; 
$search = htmlentities($_POST['recherche']);
$resultat= $data->rechercher($search);
$sous_category = [];
foreach($resultat[0] as$sous_cat){
    $sous_category[]= $data->query("SELECT * FROM sous_category WHERE sous_category.category=".$sous_cat['sous_category']." ");
}

if($resultat[3]===0){
    header('Location: http://localhost/iska/product/empty-search.php'); 
    exit;
}elseif(!empty($resultat[0])) {
    require_once '../elements/header.php';

    // var_dump($all_category);

    
}elseif(!empty($resultat[1])){
    $id = $resultat[1][0]['id'];
    header("Location: http://localhost/iska/product/category.php?id=$id"); 
    exit;
}else{
    require_once '../elements/header.php';

    var_dump($resultat);
}
// var_dump($sous_category);
// var_dump($resultat);
?>
<style>
    .mode
        {
            height: 100%;
            border:1px solid red;
        } 
</style>


        <!--====== App Content ======-->
        <div class="app-content">
 
            <!--====== Section 1 ======-->
            
                <div class="container">
                    <div class="row">
                        
                        <div class="col-lg-12">
                            <div class="shop-p">
                                <div class="shop-p__toolbar u-s-m-b-30">
                                    <div class="shop-p__meta-wrap u-s-m-b-60">

                                        <span class="shop-p__meta-text-1"><?= $resultat[3];?> Résultas trouvés pour "<?= $search ?>" </span>
                                        <div class="shop-p__meta-text-2">

                                            <span>Recherches associées:</span>

                                            <?php foreach($sous_category as $k => $sc): ?>
                                                <?php for($i=0; $i< count($sous_category[$k]);$i++):?>
                                                    <a class="gl-tag btn--e-brand-shadow" href="#"><?= $sc[$i]['name']?></a>
                                                <?php endfor ?>
                                            <?php endforeach?>
                                        </div>
                                    <div class="shop-p__tool-style">
                                        <div class="tool-style__group u-s-m-b-8">
                                            
                                        
                                            <span class="js-shop-grid-target is-active">Grille</span>

                                            <span class="js-shop-list-target">Liste</span>
                                        </div>
                                        <form>
                                            <div class="tool-style__form-wrap">
                                                <div class="u-s-m-b-8"><select class="select-box select-box--transparent-b-2">
                                                        <option>Spectacle: 8</option>
                                                        <option selected>Spectacle: 12</option>
                                                        <option>Spectacle: 16</option>
                                                        <option>Spectacle: 28</option>
                                                    </select></div>
                                                <div class="u-s-m-b-8"><select class="select-box select-box--transparent-b-2">
                                                        <option selected>Trier par: Articles les plus récents</option>
                                                        <option>Trier par: Derniers articles</option>
                                                        <option>Trier par: Meilleure vente</option>
                                                        <option>Trier par: Meilleure cote</option>
                                                        <option>Trier par: Prix ​​le plus bas</option>
                                                        <option>Trier par: Le prix le plus élevé</option>
                                                    </select></div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="shop-p__collection">
                                    <div class="row is-grid-active">
                                        <?php for($i=0; $i<count($resultat[0]);$i++): ?>
                                            <?php if($i<12) : ?>
                                            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6">
                                                <div class="product-m flex-nowrap" >
                                                    <div class="product-m__thumb " style="padding-top:1rem; width: 20%; min-width: 200px;">

                                                        <a class="aspect  aspect--square " href="content.php?id=<?=  $resultat[0][$i]['id']?>">

                                                            <img class="img-thumbnail" src="../<?= $resultat[0][$i]['image'];?>" alt=""></a>
                                                        <div class="product-m__quick-look">

                                                            <a class="fas fa-search" data-modal="modal" data-modal-id="#quick-look" data-tooltip="tooltip" data-placement="top" title="Quick Look"></a></div>
                                                        <div class="product-m__add-cart">

                                                            <a class="btn--e-brand" data-modal="modal" data-modal-id="#add-to-cart">Ajouter au chariot</a></div>
                                                    </div>
                                                    <div class="product-m__content">
                                                        <!-- <div class="product-m__category">

                                                            <a href="shop-side-version-2.html">
                                                                <?php $category = $data->name_category($resultat[0][$i]['id']); ?>
                                                                    <?= $category[0]['name'];?></a>
                                                        </div> -->
                                                        <div class="text-center" style="padding-top:1rem;">

                                                            
                                                            <div class="product-m__name" >

                                                                <a style="color:rgba(0,0,0,0.5);font-size:0.9rem;" href="content.php?id=<?=  $resultat[0][$i]['id']?>"><?= $resultat[0][$i]['name'];?></a></div>
                                                            <!-- <div class="product-m__rating gl-rating-style"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i><i class="far fa-star"></i><i class="far fa-star"></i>

                                                                <span class="product-m__review">(23)</span></div> -->
                                                            <div class="product-m__price gl-tag " style="font-size:1rem;"><?= $resultat[0][$i]['price'];?>F</div>
                                                            <div class="product-m__hover">
                                                                <div class="product-m__preview-description">

                                                                    <span><?=  $resultat[0][$i]['description']?>.</span></div>
                                                                <div class="product-m__wishlist">

                                                                    <a class="far fa-heart" href="#" data-tooltip="tooltip" data-placement="top" title="Add to Wishlist"></a></div>
                                                                </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endif;?>
                                        <?php endfor; ?>                                        
                                    </div>
                                </div>
                                <div class="u-s-p-y-60">

                                    <!--====== Pagination ======-->
                                    <ul class="shop-p__pagination">
                                        <li class="is-active">

                                            <a href="shop-grid-left.html">1</a></li>
                                        <li>

                                            <a href="shop-grid-left.html">2</a></li>
                                        <li>

                                            <a href="shop-grid-left.html">3</a></li>
                                        <li>

                                            <a href="shop-grid-left.html">4</a></li>
                                        <li>

                                            <a class="fas fa-angle-right" href="shop-grid-left.html"></a></li>
                                    </ul>
                                    <!--====== End - Pagination ======-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            
            <!--====== End - Section 1 ======-->
        </div>
        <!--====== End - App Content ======-->


        <?php require_once '../elements/footer.php'; ?>