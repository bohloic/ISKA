<?php 
require_once '../elements/header.php'; 
$produit = $data-> product_by_Category();
// var_dump($produit);
?>
        <!--====== App Content ======-->
        <div class="app-content mt-2">

            <!--====== Section 1 ======-->
           
                <div class="container" >
                    <div class="row flex-nowrap" >
                
                        <!-- menu categorie -->
                        <?php require_once 'menu-product.php';?>

                        <!-- contenu d'une categorie -->
                        <div class="cat-main" >
                            <div class="row" >

                                <div class="col-sm-12 ">
                                <?php  if(!empty($produit)) :?>
                                                        
                                    

                                    
                                    <div class="container mt-3">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="section__text-wrap">
                                                    <h1 class="section__heading u-c-secondary u-s-m-b-12"><?=strtoupper($produit[0]['cat'])?> </h1>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                <!--====== End - Section Intro ======-->


                                <!--====== Section Content ======-->
                                
                                    <div class=" mt-3">
                                        <div class="row">
                                            
                                                <?php for($i=0;$i< count($produit);$i++) : ?>
                                                <div class="col-md-3 col-sm-6 col-xs-6 mt-1">
                                                    <div class="product-o product-o--hover-on" style="width: 20%; min-width: 200px; ">
                                                        <div class="product-o__wrap" >

                                                            <a class="aspect  aspect--square u-d-block" href="../product/content.php?id=<?= $produit[$i]['id']; ?>">

                                                                <img class="aspect__img" src="../<?= $produit[$i]['img']; ?>" alt="">
                                                            </a>
                                                            
                                                        </div>
                                                        <div class="text-center" style="padding-top:1rem;">
                                                            <!-- <span class="product-o__category">

                                                                <a href="../product/category.php?id=<?=$produit[$i]['idCat']?> "><?= $produit[$i]['cat']; ?></a></span> -->

                                                            <span class="product-o__name">

                                                                <a style="color:rgba(0,0,0,0.5);font-size:0.9rem;" href="../product/content.php?id=<?= $produit[$i]['id']; ?>"><?= $produit[$i]['prod']; ?></a></span>
                                                            <!-- <div class="product-o__rating gl-rating-style"><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i>

                                                                <span class="product-o__review">(0)</span></div> -->

                                                            <span style="font-size:1rem;" class="product-o__price"><?= $produit[$i]['prix']; ?>F
                                                            <a href="../page/addpanier.php?id=<?= $produit[$i]['id']?>" data-modal="modal" data-modal-id="#add-to-cart" data-tooltip="tooltip" class="addPanier" data-placement="top" title="Add to Cart">
                                                                <i class="fas fa-plus-circle" style="color:green"></i>
                                                            </a>

                                                                <!-- <span class="product-o__discount"><?= $produit[$i]['prix']; ?>F</span> -->
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endfor ;?>
                                            </div>
                                        </div>                                               
                                    </div>
                                        
                                        <!--====== End - Section Content ======-->
                                        
                                    
                                    
                                         
                                    
                                        
                                    <?php endif;?>                    
                                </div>
                            </div>
                        </div>
       
                    </div>
                </div>
           
            <!--====== End - Section 1 ======-->
        </div>
        <!--====== End - App Content ======-->


<?php require_once '../elements/footer.php'; ?>