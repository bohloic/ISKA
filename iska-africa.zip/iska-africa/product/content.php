<?php
require_once '../elements/header.php'; 
$produit = $data->displayProduit();
$tout_produit = $data->query("SELECT * FROM product WHERE category=".$produit[0]['idCat']);
$produitVue = $data->tri('vue', $tout_produit);
// var_dump($produitVue);
//faire une boucle differente pour les 3 row


?>

        <!--====== App Content ======-->
        <div class="app-content">
            
            <!--====== Section 1 ======-->
            
            <div class="u-s-p-t-90">
                <div class="container">
                    <div class="row">
                        
                        <div class="col-lg-5">

                            <!--====== Product Breadcrumb ======-->
                            <div class="pd-breadcrumb u-s-m-b-30">
                                <ul class="pd-breadcrumb__list">
                                    <li class="has-separator">

                                        <a href="../page/index.php">Accueil</a></li>
                                    <li class="has-separator">

                                        <a href="../product/category.php?id=<?=$produit[0]['idCat']?>"><?= $produit[0]['cat']; ?></a></li>
                                    <li class="has-separator">

                                        <a href="../shop-side-version-2.php"><?= $produit[0]['sous_cat']; ?></a></li>
                                    <li class="is-marked">

                                        <a href="/iska/product/content.php?id=<?=  $produit[0]['id']?>"><?= $produit[0]['prod']; ?></a></li>
                                </ul>
                            </div>
                            <!--====== End - Product Breadcrumb ======-->


                            <!--====== Product Detail Zoom ======-->
                            <div class="pd u-s-m-b-30">
                                <div class="slider-fouc pd-wrap">
                                    <div id="pd-o-initiate">
                                        <div class="pd-o-img-wrap" data-src="images/product/product-d-1.jpg">

                                            <img class="u-img-fluid" src="../<?= $produit[0]['img']; ?>" data-zoom-image="../<?= $produit[0]['img']; ?>" alt=""></div>
                                        <div class="pd-o-img-wrap" data-src="../<?= $produit[0]['img']; ?>">

                                            <img class="u-img-fluid" src="../<?= $produit[0]['img']; ?>" data-zoom-image="../<?= $produit[0]['img']; ?>" alt=""></div>
                                        <div class="pd-o-img-wrap" data-src="../<?= $produit[0]['img']; ?>">

                                            <img class="u-img-fluid" src="../images/product/product-d-3.jpg" data-zoom-image="../<?= $produit[0]['img']; ?>" alt=""></div>
                                        <div class="pd-o-img-wrap" data-src="../<?= $produit[0]['img']; ?>">

                                            <img class="u-img-fluid" src="../images/product/product-d-4.jpg" data-zoom-image="../<?= $produit[0]['img']; ?>" alt=""></div>
                                        <div class="pd-o-img-wrap" data-src="../<?= $produit[0]['img']; ?>">

                                            <img class="u-img-fluid" src="../<?= $produit[0]['img']; ?>" data-zoom-image="../<?= $produit[0]['img']; ?>" alt=""></div>
                                    </div>

                                    <span class="pd-text">Click for larger zoom</span>
                                </div>
                                <div class="u-s-m-t-15">
                                    <div class="slider-fouc">
                                        <div id="pd-o-thumbnail">
                                            <div>

                                                <img class="u-img-fluid" src="../<?= $produit[0]['img']; ?>" alt=""></div>
                                            <div>

                                                <img class="u-img-fluid" src="../<?= $produit[0]['img']; ?>" alt=""></div>
                                            <div>

                                                <img class="u-img-fluid" src="../<?= $produit[0]['img']; ?>" alt=""></div>
                                            <div>

                                                <img class="u-img-fluid" src="../<?= $produit[0]['img']; ?>" alt=""></div>
                                            <div>

                                                <img class="u-img-fluid" src="../<?= $produit[0]['img']; ?>" alt=""></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--====== End - Product Detail Zoom ======-->
                        </div>
                        <div class="col-lg-7">

                            <!--====== Product Right Side Details ======-->
                            <div class="pd-detail">
                                <div>

                                    <span class="pd-detail__name"><?= $produit[0]['prod']; ?></span></div>
                                <div>
                                    <div class="pd-detail__inline">

                                        <span class="pd-detail__price"><?= $produit[0]['prix']; ?>F</span>

                                        <span class="pd-detail__discount">(76% DÉSACTIVÉ)</span><del class="pd-detail__del"><?= $produit[0]['prix']; ?></del></div>
                                </div>
                                <div class="u-s-m-b-15">
                                    <div class="pd-detail__rating gl-rating-style"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>

                                        <span class="pd-detail__review u-s-m-l-4">

                                            <a data-click-scroll="#view-review"> Commentaires</a></span></div>
                                </div>
                                <div class="u-s-m-b-15">
                                    <div class="pd-detail__inline">

                                        <span class="pd-detail__stock"><?= $produit[0]['stock']; ?> en stock</span>

                                        <span class="pd-detail__left">Seulement 2 restants</span></div>
                                </div>
                                <div class="u-s-m-b-15">

                                    <span class="pd-detail__preview-desc"><?= $produit[0]['descri']; ?>.</span></div>
                                <div class="u-s-m-b-15">
                                    <div class="pd-detail__inline">

                                        <span class="pd-detail__click-wrap"><i class="far fa-heart u-s-m-r-6"></i>

                                            <a href="signin.html">Ajouter à la liste d'envies</a>

                                        </span>
                                    </div>
                                </div>
                                <div class="u-s-m-b-15">
                                    <div class="pd-detail__inline">

                                        <span class="pd-detail__click-wrap"><i class="far fa-envelope u-s-m-r-6"></i>

                                            <a href="signin.html">Envoyez-moi un e-mail lorsque le prix baisse</a>

                                        </span> 
                                    </div>
                                </div>
                                
                                <div class="u-s-m-b-15">
                                    <form class="pd-detail__form">
                                        <div class="u-s-m-b-15">

                                            <span class="pd-detail__label u-s-m-b-8">Coleur:</span>
                                            <div class="pd-detail__color">
                                                <div class="color__radio">

                                                    <input type="radio" id="jet" name="color" checked>

                                                    <label class="color__radio-label" for="jet" style="background-color: #333333"></label></div>
                                                <div class="color__radio">

                                                    <input type="radio" id="folly" name="color">

                                                    <label class="color__radio-label" for="folly" style="background-color: #FF0055"></label></div>
                                                <div class="color__radio">

                                                    <input type="radio" id="yellow" name="color">

                                                    <label class="color__radio-label" for="yellow" style="background-color: #FFFF00"></label></div>
                                                <div class="color__radio">

                                                    <input type="radio" id="granite-gray" name="color">

                                                    <label class="color__radio-label" for="granite-gray" style="background-color: #605F5E"></label></div>
                                                <div class="color__radio">

                                                    <input type="radio" id="space-cadet" name="color">

                                                    <label class="color__radio-label" for="space-cadet" style="background-color: #1D3461"></label></div>
                                            </div>
                                        </div>
                                        <div class="u-s-m-b-15">

                                            <span class="pd-detail__label u-s-m-b-8">Taille:</span>
                                            <div class="pd-detail__size">
                                                <div class="size__radio">

                                                    <input type="radio" id="xs" name="size" checked>

                                                    <label class="size__radio-label" for="xs">XS</label></div>
                                                <div class="size__radio">

                                                    <input type="radio" id="small" name="size">

                                                    <label class="size__radio-label" for="xxl">Small</label></div>
                                                <div class="size__radio">

                                                    <input type="radio" id="medium" name="size">

                                                    <label class="size__radio-label" for="medium">Medium</label></div>
                                                <div class="size__radio">

                                                    <input type="radio" id="large" name="size">

                                                    <label class="size__radio-label" for="xxl">Large</label></div>
                                                <div class="size__radio">

                                                    <input type="radio" id="xl" name="size">

                                                    <label class="size__radio-label" for="xl">XL</label></div>
                                                <div class="size__radio">

                                                    <input type="radio" id="xxl" name="size">

                                                    <label class="size__radio-label" for="xxl">XXL</label></div>
                                            </div>
                                        </div>
                                        <div class="pd-detail-inline-2">
                                            <div class="u-s-m-b-15">

                                                <!--====== Input Counter ======-->
                                                <div class="input-counter">

                                                    <span class="input-counter__minus fas fa-minus"></span>

                                                    <input class="input-counter__text input-counter--text-primary-style" type="text" value="1" data-min="1" data-max="1000">

                                                    <span class="input-counter__plus fas fa-plus"></span></div>
                                                <!--====== End - Input Counter ======-->
                                            </div>
                                            <div class="u-s-m-b-15">
                                                <a data-modal="modal" class="addPanier btn btn--e-brand-b-2" href="../page/addpanier.php?id=<?=  $produit[0]['id']?>" data-modal-id="#add-to-cart" >Ajouter au panier</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="u-s-m-b-15">

                                    <span class="pd-detail__label u-s-m-b-8">Politique de produit :</span>
                                    <ul class="pd-detail__policy-list">
                                        <li><i class="fas fa-check-circle u-s-m-r-8"></i>

                                            <span>Protection de l'acheteur.</span></li>
                                        <li><i class="fas fa-check-circle u-s-m-r-8"></i>

                                            <span>Remboursement intégral si vous ne recevez pas votre commande.</span></li>
                                        <li><i class="fas fa-check-circle u-s-m-r-8"></i>

                                            <span>Retours acceptés si produit non conforme à la description.</span></li>
                                    </ul>
                                </div>
                            </div>
                            <!--====== End - Product Right Side Details ======-->
                        </div>
                        
                    </div>
                </div>
            </div>

            <br><br>
            <div class="u-s-p-b-90">

                <!--====== Section Intro ======-->
                <div class="section__intro u-s-m-b-46">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="section__text-wrap">
                                    <h1 class="section__heading u-c-secondary u-s-m-b-12">UN CLIENT A ÉGALEMENT VISITÉ</h1>

                                    <span class="section__span u-c-grey">PRODUITS VISÉS PAR LE CLIENT</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Intro ======-->


                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="slider-fouc">
                            <div class="owl-carousel product-slider" data-item="4">
                                <?php for($i=0;$i<count($produitVue);$i++): ?>
                                <?php if($i<4): ?>
                                <div class="u-s-m-b-30">
                                    <div class="product-o product-o--hover-on">
                                        <div class="product-o__wrap">

                                            <a class="aspect aspect--bg-grey aspect--square u-d-block" href="product-detail.html">

                                                <img class="aspect__img" src="../<?= $produitVue[$i]['image']; ?>" alt=""></a>
                                            <div class="product-o__action-wrap">
                                                <ul class="product-o__action-list">
                                                    <li>

                                                        <a data-modal="modal" data-modal-id="#quick-look" data-tooltip="tooltip" data-placement="top" title="Quick View"><i class="fas fa-search-plus"></i></a></li>
                                                    <li>

                                                        <a data-modal="modal" class="addPanier" href="../page/addpanier.php?id=<?= $produitVue[$i]['id']?>" data-modal-id="#add-to-cart" data-tooltip="tooltip" data-placement="top" title="Add to Cart"><i class="fas fa-plus-circle"></i></a></li>
                                                    <li>

                                                        <a href="signin.html" data-tooltip="tooltip" data-placement="top" title="Add to Wishlist"><i class="fas fa-heart"></i></a></li>
                                                    <li>

                                                        <a href="signin.html" data-tooltip="tooltip" data-placement="top" title="Email me When the price drops"><i class="fas fa-envelope"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>

                                        <span class="product-o__category">

                                            <a href="../product/category.php?id=<?=$produit[0]['idCat']?>"><?= $produit[0]['cat']; ?></a></span>

                                        <span class="product-o__name">

                                            <a href="product-detail.html"><?= $produitVue[$i]['name']; ?></a></span>
                                        <div class="product-o__rating gl-rating-style"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>

                                            <span class="product-o__review">(20)</span></div>

                                        <span class="product-o__price"><?= $produitVue[$i]['price']; ?> F

                                            <span class="product-o__discount"><?= $produitVue[$i]['price']; ?> F</span></span>
                                    </div>
                                </div>
                                <?php endif ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 1 ======-->
        </div>
        <!--====== End - App Content ======-->


        <?php require_once '../elements/footer.php'; ?>
