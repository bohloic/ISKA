<?php 
require_once '../elements/header.php'; 
$category = $data->query('SELECT * FROM category');
// var_dump($category);
?>
        <!--====== App Content ======-->
        <div class="app-content mt-2">

            <!--====== Section 1 ======-->
           
                <div class="">
                    <div class="row flex-nowrap">
                        <?php require_once 'menu-product.php';?>
                        <div class="cat-main">
                            <div class="row">

                                <div class="col-md-12 ">
                                    <?php for($j=0;$j<count($category);$j++) : ?>                                    
                                    <?php $produit= $data->query('SELECT * FROM `product` WHERE category = '.$category[$j]['id']) ; ?>                            
                                    <?php  if(!empty($produit)) :?>

                                    <div class="u-s-p-b-5 mt-5 mb-5">

                                        <!--====== Section Intro ======-->
                                        <div class="section__intro u-s-m-b-20">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="section__text-wrap">
                                                            <h1 class="section__heading u-c-secondary u-s-m-b-12"><?=$category[$j]['name']?> </h1>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--====== End - Section Intro ======-->


                                        <!--====== Section Content ======-->
                                        <div class="section__content" style="width:90%;">
                                            <div class="container">
                                                <div class="" >
                                                    <div class="owl-carousel product-slider" data-item="4"> 
                                                        <?php for($i=0;$i< count($produit);$i++) : ?>
                                                        <div class="u-s-m-b-4">
                                                            <div class="product-o product-o--hover-on" style="width: 20%; min-width: 200px;">
                                                                <div class="product-o__wrap">

                                                                    <a class="aspect aspect--bg-grey aspect--square u-d-block" href="../product/content.php?id=<?= $produit[$i]['id']; ?>">

                                                                        <img class="aspect__img img-thumbnail" src="../<?= $produit[$i]['image']; ?>" alt=""></a>
                                                                    <div class="product-o__action-wrap">
                                                                        <ul class="product-o__action-list">
                                                                            <li>

                                                                                <a data-modal="modal" data-modal-id="#quick-look" data-tooltip="tooltip" data-placement="top" title="Quick View"><i class="fas fa-search-plus"></i></a></li>
                                                                            <li>

                                                                                <a data-modal="modal" class="addPanier" href="../page/addpanier.php?id=<?= $produit[$i]['id']?>" data-modal-id="#add-to-cart" data-tooltip="tooltip" data-placement="top" title="Add to Cart"><i class="fas fa-plus-circle"></i></a></li>
                                                                            <li>

                                                                                <a href="../signin.html" data-tooltip="tooltip" data-placement="top" title="Add to Wishlist"><i class="fas fa-heart"></i></a></li>
                                                                            <li>

                                                                                <a href="../signin.html" data-tooltip="tooltip" data-placement="top" title="Email me When the price drops"><i class="fas fa-envelope"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                                <span class="product-o__category">

                                                                    <a href="../product/category.php?id=<?=$category[$j]['id']?> "><?=$category[$j]['name']?> </a></span>

                                                                <span class="product-o__name">

                                                                    <a href="../product/content.php?id=<?= $produit[$i]['id']; ?>"><?= $produit[$i]['name']; ?></a></span>
                                                                <!-- <div class="product-o__rating gl-rating-style"><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i>

                                                                    <span class="product-o__review">(0)</span></div> -->

                                                                <span class="product-o__price"><?= $produit[$i]['price']; ?>F

                                                                    <!-- <span class="product-o__discount"><?= $produit[$i]['price']; ?>F</span> -->
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <?php endfor ;?>
                                                    </div>
                                                    <div class=" text-center">
                                                        <a class="btn btn--e-brand" type="button" href="../product/category.php?id=<?= $category[$j]['id'] ?>">Voir Plus</a> 
                                                    </div>
                                                </div>                                               
                                            </div>
                                        </div>
                                        <!--====== End - Section Content ======-->
                                        
                                    </div>
                                    
                                        <?php if($j<5) : ?>
                                            <div class="horizontal-line mt-5 mb-5"></div>
                                        <?php endif; ?>  
                                    <?php endif;?>
                                    <?php endfor; ?>                        
                                </div>
                            </div>
                        </div>
       
                    </div>
                </div>
           
            <!--====== End - Section 1 ======-->
        </div>
        <!--====== End - App Content ======-->


<?php require_once '../elements/footer.php'; ?>