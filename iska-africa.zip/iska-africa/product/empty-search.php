<?php require_once '../elements/header.php'; ?>

        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Section 1 ======-->
            <div class="u-s-p-y-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 u-s-m-b-30">
                                <div class="empty">
                                    <div class="empty__wrap">

                                        <span class="empty__big-text">DESOLE</span>

                                        <span class="empty__text-1">Votre recherche ne correspond à aucun produit. Une correspondance partielle de vos mots-clés est la liste ci-dessous.</span>

                                        <span class="empty__text-2">Recherches relatives:

                                            <a href="shop-side-version-2.html">men's clothing</a>

                                            <a href="shop-side-version-2.html">mobiles & tablets</a>

                                            <a href="shop-side-version-2.html">books & audible</a>
                                        </span>  
                                        <form class="form-inline my-2 my-lg-0 empty__search-form" method="post" action="../product/search.php" style="width: 30%; min-width: 300px;">
                                            <input class="form-control mr-sm-2" type="search" name="recherche" placeholder="Search" aria-label="Search">                                        
                                            <button class="btn btn-outline-success my-2 my-sm-0 btn--icon fas fa-search" type="submit"></button>                                                                 
                                        </form>      
                                                                                                                
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 1 ======-->
        </div>
        <!--====== End - App Content ======-->



        <?php require_once '../elements/footer.php'; ?>