
<style>

.hero-slide {
  background: center center/cover no-repeat; }
  .hero-slide--1 {
    background-image: url(../images/slider/6.jpg); }
  .hero-slide--2 {
    background-image: url(../images/slider/21.jpg); }
  .hero-slide--3 {
    background-image: url(../images/slider/23.jpg); }
  .hero-slide--4 {
    background-image: url(../images/slider/7.jpg); }
  .hero-slide--5 {
    background-image: url(../images/slider/9.jpg); }
  .hero-slide--6 {
    background-image: url(../images/slider/17.jpg); }
  .hero-slide--7 {
    background-image: url(../images/slider/22.jpg); }
  .hero-slide--8 {
    background-image: url(../images/slider/13.jpg); }
  .hero-slide--9 {
    background-image: url(../images/slider/9.jpg); }
    .owl-carousel .owl-dots {
  position: absolute; }

.owl-carousel button.owl-dot:focus {
  outline: 0; }

.owl-carousel.primary-style-1 .owl-dots {
  top: 50%;
  -webkit-transform: translateY(-50%);
          transform: translateY(-50%);
  right: 40px; }

.owl-carousel.primary-style-1 button.owl-dot {
  width: 14px;
  height: 14px;
  border-radius: 50%;
  display: block;
  margin-bottom: 6px;
  background: #e1e1e1;
  transition: background 0.8s ease-out; }
  .owl-carousel.primary-style-1 button.owl-dot:last-child {
    margin-bottom: 0; }
  .owl-carousel.primary-style-1 button.owl-dot.active, .owl-carousel.primary-style-1 button.owl-dot:hover {
    background: transparent linear-gradient(-180deg, #ff4500 0%, #ff6a33 100%); }

.owl-carousel.primary-style-2 .owl-dots {
  width: 100%;
  text-align: center;
  bottom: 20px; }

.owl-carousel.primary-style-2 button.owl-dot {
  width: 11px;
  height: 11px;
  display: inline-block;
  margin-right: 4px;
  border-radius: 50%;
  background-color: #7f7f7f;
  transition: background 0.8s ease-out; }
  .owl-carousel.primary-style-2 button.owl-dot:last-child {
    margin-right: 0; }
  .owl-carousel.primary-style-2 button.owl-dot.active, .owl-carousel.primary-style-2 button.owl-dot:hover {
    background-color: #ffffff; }


</style>

<div class="owl-carousel primary-style-1 mb-4" id="hero-slider">

                    <div class="hero-slide hero-slide--1">
                    
                        <div class="container">
                        
                            <div class="row">
                                <div class="col-12">
                                
                                  <div class="slider-content slider-content--animation">
                                  
                                    
                                        <span class="content-span-1 u-c-white" >Dernière mise à jour Stock</span>

                                        <span class="content-span-2 u-c-white">30% de réduction sur l'électronique</span>

                                        <span class="content-span-3 u-c-white">Trouvez de l'électronique aux meilleurs prix, Découvrez également les produits électroniques les plus vendus</span>

                                        <span class="content-span-4 u-c-white">À partir de

                                            <span class="u-c-brand">10000 F</span></span>

                                        <a class="shop-now-link btn--e-brand" href="../product/category.php">ACHETEZ MAINTENANT</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hero-slide hero-slide--2">
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <div class="slider-content slider-content--animation">

                                        <span class="content-span-1 u-c-white">Trouver les meilleures marques</span>

                                        <span class="content-span-2 u-c-white">10% de réduction sur l'électronique</span>

                                        <span class="content-span-3 u-c-white">Trouvez de l'électronique aux meilleurs prix, Découvrez également les produits électroniques les plus vendus</span>

                                        <span class="content-span-4 u-c-white">À partir de

                                            <span class="u-c-brand">10000 F</span></span>

                                        <a class="shop-now-link btn--e-brand" href="../product/category.php">ACHETEZ MAINTENANT</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hero-slide hero-slide--3">
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <div class="slider-content slider-content--animation">

                                        <span class="content-span-1 u-c-white">Trouver les meilleures marques</span>

                                        <span class="content-span-2 u-c-white">10% de réduction sur l'électronique</span>

                                        <span class="content-span-3 u-c-white">Trouvez de l'électronique aux meilleurs prix, Découvrez également les produits électroniques les plus vendus</span>

                                        <span class="content-span-4 u-c-white">À partir de

                                            <span class="u-c-brand">5000 F</span></span>

                                        <a class="shop-now-link btn--e-brand" href="../product/category.php">ACHETEZ MAINTENANT</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>