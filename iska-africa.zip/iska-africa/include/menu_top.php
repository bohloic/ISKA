<?php
require_once '../elements/_header.php';
$categories = $data->query("SELECT * FROM category");
$sous_categories = [];
for($i=1;$i<count($categories);$i++){
    $sous_categories[] = $data->query("SELECT sous_category.name as souscat, category.name as cat 
    FROM sous_category,category WHERE category.id=sous_category.category AND category.id=$i"); 
}
// var_dump($sous_categories); 
// var_dump($categories);
?>
<style>

    /*Style the menu-cat */
    .menu-cat {
        position:absolute ;
        margin-top:0px
        
    }
    /* Style the tab */
.tab {
    float: left;
    border: 1px solid #ccc;
    border-top: none;
    border-bottom: none;
    /* background-color: #f1f1f1; */
    width: 30%;
    text-align:center;
    /* height: 300px; */
    position: relative;
  }
  
  /* Style the buttons that are used to open the tab content */
  .tab a {
    display: block;
    background-color: inherit;
    color: black;
    padding-right: 5rem;
    width: 100%;
    border: none;
    outline: none;
    text-align: left;
    cursor: pointer;
  }
  
  /* Change background color of buttons on hover */
  .tab a:hover {
    /* background-color: #ddd; */
    /* background-color: rgba(0,255,0,0.5); */
    background-color: rgba(0,0,0,0.1);
    color:#000;
  }
  
  /* Create an active/current "tab button" class */
  .tab a.active {
    /* background-color: rgba(0,255,0,0.3); */
    background-color: rgba(0,0,0,0.1);
    color:#000;
  }
  
  /* Style the tab content */
  .tabcontent {
    float: left;
    padding: 0px 12px;
    border : none;
    width: 70%;
    height: 100%;
    display: none;
    background: #fff;
    
  }

  .boxcontent {
      display:inline-block;
      /* border: 1px solid #ccc; */
      border-left: none;
      border-right: none;
  }

  /* .boxcontent h4 {
      text-align:center;
  } */

  .boxcontent ul li {
    list-style: none;
    
  }

  
</style>
                
<!--====== Search Form ======--> 
<!-- <form class="main-form" method="post" action="../product/search.php">

<label for="main-search"></label>

<input class="input-text input-text--border-radius input-text--style-1" name="recherche" type="text" id="main-search" placeholder="Search">

<button class="btn btn--icon fas fa-search main-search-button" type="submit"></button>
</form> -->
<!--====== End - Search Form ======--> 





<nav class="navbar navbar-expand-md navbar-light menu" data-sticky >
    <div class="row " style="padding-left:1rem; width:100%">
        <div class="col-md-2 col-xs-4 menu-box">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a class="navbar-brand" href="<?= $extention;?>index.php"><img src="../images/logo/logo.jpg" alt="ISKA" style="width:80px; height:40px"></a>
        </div>    
        
        <div class="col-md-7 menu-box" >
            <div class="collapse navbar-collapse" id="navbarSupportedContent" >
                <div class="container">
                    <div class="row ">
                        
                        
                        <div class="col-md-12 flex-wrap text-center" >                  
                                                   

                            <ul class="navbar-nav mr-auto">
                                <li class="nav-item ">
                                    <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="far fa-user-circle"></i> Categories
                                    </a>
                                    <div class="dropdown-menu text-center  menu-cat"  aria-labelledby="navbarDropdown">
                                       
                                        <div class="tab" >                                    
                                            <?php foreach($categories as $category) :?> 
                                                <a class="dropdown-item  tablinks " onmouseover="openCity(event, '<?= $category['name'] ?>')" href="../product/category.php?id=<?= $category['id']?> ">
                                                    <?= $category['name'] ?>
                                                </a>  
                                            <?php endforeach ?>
                                        </div>
                                        
                                        
                                            
                                        <?php for($j=0;$j<count($categories);$j++): ?>
                                            
                                                
                                            <div id="<?= $categories[$j]['name'] ?>" class="tabcontent"> 
                                            <?php if(!empty($sous_categories[$j])): ?>
                                                <?php foreach($sous_categories[$j] as $k => $sous_cat): ?>    
                                                    <div class="boxcontent">                                                       
                                                        <h4>
                                                            <a class=""> <?= $sous_cat['souscat'] ?></a>
                                                        </h4>
                                                        
                                                        <!-- <div class="horizontal-line"></div> -->

                                                        <ul>
                                                            <li>Marque 1</li>
                                                            <li>Marque 2</li>
                                                            <li>Marque 3</li>
                                                            <li>Marque 4</li>
                                                            <li>Marque 5</li>
                                                        </ul> 
                                                    </div>   
                                                <?php endforeach ?>      
                                            <?php endif ?>                                              
                                            </div>
                                            
                                        <?php endfor ?>
                                        
                                    </div>
                                    
                                                                                        
                                    
                                            
                                                    
                                                
                                            
                                        
                                    
                                    
                                </li>               
                                <li class="nav-item  ">
                                    <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="far fa-user-circle"></i> Compte
                                    </a>
                                    <div class="dropdown-menu text-center" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="../user/signin.php">Connexion</a>
                                        <a class="dropdown-item" href="../user/signup.php">Inscription</a>
                                    </div>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="far fa-flag"></i> Pays
                                    </a>
                                    <div class="dropdown-menu text-center" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="#">Maroc</a>
                                        <a class="dropdown-item" href="#">Cote d'ivoire</a>
                                        <a class="dropdown-item" href="#">Angola</a>
                                        <a class="dropdown-item" href="#">Benin</a>
                                        <a class="dropdown-item" href="#">Nigeria</a>
                                        <a class="dropdown-item" href="#">Kenya</a>
                                        <a class="dropdown-item" href="#">RDC</a>
                                        <a class="dropdown-item" href="#">Conakry</a>
                                        <a class="dropdown-item" href="#">Senegal</a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link text-white" href="../page/cart.php" ><i class="fas fa-shopping-cart"></i> Panier (<span id="count"><?= $panier->count() ?></span>) </a>
                                </li>
                                <?php if(connected()): ?>
                                <li class="nav-item" >
                                    <a class="nav-link text-white" href="../user/logout.php">Se déconnecter</a>
                                </li>    
                                <?php endif ?>
                            </ul>
                        </div>
                        
                    </div>
                    
                </div>
            </div>
            
        </div>

        <div class="col-md-3 col-xs-6 menu-box">
            <form class="form-inline my-2 my-lg-0" method="post" action="../product/search.php">
                <input class="form-control mr-sm-2" type="search" name="recherche" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success my-2 my-sm-0 btn--icon fas fa-search" type="submit"></button>
            </form> 
        </div>
    </div>
</nav>

    
<!--====== End - Nav 1 ======-->