<!--====== Nav 2 ======-->
<nav class="secondary-nav-wrapper">
                <div class="container">

                    <!--====== Secondary Nav ======-->
                    <div class="secondary-nav">

                        <!--====== Dropdown Main plugin ======-->
                        <div class="menu-init" id="navigation1">

                            <button class="btn btn--icon toggle-mega-text toggle-button" type="button">M</button>

                            <!--====== Menu ======-->
                            <div class="ah-lg-mode">

                                <span class="ah-close">✕ Close</span>

                                <!--====== List ======-->
                                <ul class="ah-list">
                                    <li class="has-dropdown">

                                        <span class="mega-text">M</span>

                                        <!--====== Mega Menu ======-->

                                        <span class="js-menu-toggle"></span>
                                        <div class="mega-menu">
                                            <div class="mega-menu-wrap">
                                                <div class="mega-menu-list">
                                                    <ul>
                                                        <li class="js-active">

                                                            <a href="../product/category.php"><i class="fas fa-tv u-s-m-r-6"></i>

                                                                <span>Electronics</span></a>

                                                            <span class="js-menu-toggle js-toggle-mark"></span></li>
                                                        <li>

                                                            <a href="../product/category.php"><i class="fas fa-female u-s-m-r-6"></i>

                                                                <span>Women's Clothing</span></a>

                                                            <span class="js-menu-toggle"></span></li>
                                                        <li>

                                                            <a href="../product/../product/category.php"><i class="fas fa-male u-s-m-r-6"></i>

                                                                <span>Men's Clothing</span></a>

                                                            <span class="js-menu-toggle"></span></li>
                                                        <li>

                                                            <a href="../index.php"><i class="fas fa-utensils u-s-m-r-6"></i>

                                                                <span>Food & Supplies</span></a>

                                                            <span class="js-menu-toggle"></span></li>
                                                        <li>

                                                            <a href="../index.php"><i class="fas fa-couch u-s-m-r-6"></i>

                                                                <span>Furniture & Decor</span></a>

                                                            <span class="js-menu-toggle"></span></li>
                                                        <li>

                                                            <a href="index.php"><i class="fas fa-football-ball u-s-m-r-6"></i>

                                                                <span>Sports & Game</span></a>

                                                            <span class="js-menu-toggle"></span></li>
                                                        <li>

                                                            <a href="index.php"><i class="fas fa-heartbeat u-s-m-r-6"></i>

                                                                <span>Beauty & Health</span></a>

                                                            <span class="js-menu-toggle"></span></li>
                                                    </ul>
                                                </div>

                                                <!--====== Electronics ======-->
                                                <div class="mega-menu-content js-active">

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">3D PRINTER & SUPPLIES</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">3d Printer</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">3d Printing Pen</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">3d Printing Accessories</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">3d Printer Module Board</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">HOME AUDIO & VIDEO</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">TV Boxes</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">TC Receiver & Accessories</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Display Dongle</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Home Theater System</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">MEDIA PLAYERS</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Earphones</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Mp3 Players</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Speakers & Radios</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Microphones</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">VIDEO GAME ACCESSORIES</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Nintendo Video Games Accessories</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Sony Video Games Accessories</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Xbox Video Games Accessories</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                    <br>

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">SECURITY & PROTECTION</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Security Cameras</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Alarm System</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Security Gadgets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">CCTV Security & Accessories</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">PHOTOGRAPHY & CAMERA</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Digital Cameras</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Sport Camera & Accessories</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Camera Accessories</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Lenses & Accessories</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">ARDUINO COMPATIBLE</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Raspberry Pi & Orange Pi</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Module Board</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Smart Robot</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Board Kits</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">DSLR Camera</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Nikon Cameras</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Canon Camera</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Sony Camera</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">DSLR Lenses</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                    <br>

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">NECESSARY ACCESSORIES</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Flash Cards</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Memory Cards</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Flash Pins</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Compact Discs</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-9 mega-image">
                                                            <div class="mega-banner">

                                                                <a class="u-d-block" href="../product/category.php">

                                                                    <img class="u-img-fluid u-d-block" src="images/banners/banner-mega-0.jpg" alt=""></a></div>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                </div>
                                                <!--====== End - Electronics ======-->


                                                <!--====== Women ======-->
                                                <div class="mega-menu-content">

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-6 mega-image">
                                                            <div class="mega-banner">

                                                                <a class="u-d-block" href="../product/category.php">

                                                                    <img class="u-img-fluid u-d-block" src="images/banners/banner-mega-1.jpg" alt=""></a></div>
                                                        </div>
                                                        <div class="col-lg-6 mega-image">
                                                            <div class="mega-banner">

                                                                <a class="u-d-block" href="../product/category.php">

                                                                    <img class="u-img-fluid u-d-block" src="images/banners/banner-mega-2.jpg" alt=""></a></div>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                    <br>

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">HOT CATEGORIES</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Dresses</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Blouses & Shirts</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">T-shirts</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Rompers</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">INTIMATES</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Bras</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Brief Sets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Bustiers & Corsets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Panties</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">WEDDING & EVENTS</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Wedding Dresses</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Evening Dresses</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Prom Dresses</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Flower Dresses</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">BOTTOMS</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Skirts</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Shorts</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Leggings</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Jeans</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                    <br>

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">OUTWEAR</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Blazers</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Basics Jackets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Trench</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Leather & Suede</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">JACKETS</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Denim Jackets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Trucker Jackets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Windbreaker Jackets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Leather Jackets</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">ACCESSORIES</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Tech Accessories</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Headwear</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Baseball Caps</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Belts</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">OTHER ACCESSORIES</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Bags</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Wallets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Watches</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Sunglasses</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                    <br>

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-9 mega-image">
                                                            <div class="mega-banner">

                                                                <a class="u-d-block" href="../product/category.php">

                                                                    <img class="u-img-fluid u-d-block" src="images/banners/banner-mega-3.jpg" alt=""></a></div>
                                                        </div>
                                                        <div class="col-lg-3 mega-image">
                                                            <div class="mega-banner">

                                                                <a class="u-d-block" href="../product/category.php">

                                                                    <img class="u-img-fluid u-d-block" src="images/banners/banner-mega-4.jpg" alt=""></a></div>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                </div>
                                                <!--====== End - Women ======-->


                                                <!--====== Men ======-->
                                                <div class="mega-menu-content">

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-4 mega-image">
                                                            <div class="mega-banner">

                                                                <a class="u-d-block" href="../product/category.php">

                                                                    <img class="u-img-fluid u-d-block" src="images/banners/banner-mega-5.jpg" alt=""></a></div>
                                                        </div>
                                                        <div class="col-lg-4 mega-image">
                                                            <div class="mega-banner">

                                                                <a class="u-d-block" href="../product/category.php">

                                                                    <img class="u-img-fluid u-d-block" src="images/banners/banner-mega-6.jpg" alt=""></a></div>
                                                        </div>
                                                        <div class="col-lg-4 mega-image">
                                                            <div class="mega-banner">

                                                                <a class="u-d-block" href="../product/category.php">

                                                                    <img class="u-img-fluid u-d-block" src="images/banners/banner-mega-7.jpg" alt=""></a></div>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                    <br>

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">HOT SALE</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">T-Shirts</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Tank Tops</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Polo</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Shirts</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">OUTWEAR</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Hoodies</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Trench</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Parkas</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Sweaters</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">BOTTOMS</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Casual Pants</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Cargo Pants</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Jeans</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Shorts</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">UNDERWEAR</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Boxers</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Briefs</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Robes</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Socks</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                    <br>

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">JACKETS</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Denim Jackets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Trucker Jackets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Windbreaker Jackets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Leather Jackets</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">SUNGLASSES</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Pilot</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Wayfarer</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Square</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Round</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">ACCESSORIES</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Eyewear Frames</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Scarves</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Hats</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Belts</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <ul>
                                                                <li class="mega-list-title">

                                                                    <a href="../product/category.php">OTHER ACCESSORIES</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Bags</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Wallets</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Watches</a></li>
                                                                <li>

                                                                    <a href="../product/category.php">Tech Accessories</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                    <br>

                                                    <!--====== Mega Menu Row ======-->
                                                    <div class="row">
                                                        <div class="col-lg-6 mega-image">
                                                            <div class="mega-banner">

                                                                <a class="u-d-block" href="../product/category.php">

                                                                    <img class="u-img-fluid u-d-block" src="images/banners/banner-mega-8.jpg" alt=""></a></div>
                                                        </div>
                                                        <div class="col-lg-6 mega-image">
                                                            <div class="mega-banner">

                                                                <a class="u-d-block" href="../product/category.php">

                                                                    <img class="u-img-fluid u-d-block" src="images/banners/banner-mega-9.jpg" alt=""></a></div>
                                                        </div>
                                                    </div>
                                                    <!--====== End - Mega Menu Row ======-->
                                                </div>
                                                <!--====== End - Men ======-->


                                                <!--====== No Sub Categories ======-->
                                                <div class="mega-menu-content">
                                                    <h5>No Categories</h5>
                                                </div>
                                                <!--====== End - No Sub Categories ======-->


                                                <!--====== No Sub Categories ======-->
                                                <div class="mega-menu-content">
                                                    <h5>No Categories</h5>
                                                </div>
                                                <!--====== End - No Sub Categories ======-->


                                                <!--====== No Sub Categories ======-->
                                                <div class="mega-menu-content">
                                                    <h5>No Categories</h5>
                                                </div>
                                                <!--====== End - No Sub Categories ======-->


                                                <!--====== No Sub Categories ======-->
                                                <div class="mega-menu-content">
                                                    <h5>No Categories</h5>
                                                </div>
                                                <!--====== End - No Sub Categories ======-->
                                            </div>
                                        </div>
                                        <!--====== End - Mega Menu ======-->
                                    </li>
                                </ul>
                                <!--====== End - List ======-->
                            </div>
                            <!--====== End - Menu ======-->
                        </div>
                        <!--====== End - Dropdown Main plugin ======-->

                    </div>
                    <!--====== End - Secondary Nav ======-->
                </div>
            </nav>
            <!--====== End - Nav 2 ======-->