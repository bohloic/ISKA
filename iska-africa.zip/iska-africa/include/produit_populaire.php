<?php 
require_once '../elements/_header.php'; 
$produits = $data->query('SELECT * FROM `product`');
$produitPopu = $data->tri('vue', $produits); 
?>

<div class="container mt-5 mb-5"> 
    <div class="section__intro u-s-m-b-20">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section__text-wrap">
                        <h1 class="section__heading u-c-secondary u-s-m-b-12">PRODUITS POPULAIRES</h1> 
        
                        <span class="section__span u-c-silver">TROUVER LES NOUVEAUX PRODUITS POPULAIRES</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--====== End - Section Intro ======-->


    <!--====== Section Content ======-->
    <div class="section__content">
        <div class="container row">
            <div class="flex-nowrap">       
                <div class=" owl-carousel product-slider" data-item="4">     
                    
                    <?php for($i=0;$i< count($produitPopu);$i++) : ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6">
                        <div class="product-o product-o--hover-on" style="margin-left:2rem; width: 20%; min-width: 200px;">
                            <div class="product-o__wrap">
                                <a class="aspect aspect--bg-grey aspect--square u-d-block" href="../product/content.php?id=<?=$produitPopu[$i]['id'] ?>">
                                    <img class="aspect__img" src="../<?=$produitPopu[$i]['image']?>" alt=""></a>
                                <!-- <div class="product-o__action-wrap">
                                    <ul class="product-o__action-list">
                                        <li>
                                            <a data-modal="modal" data-modal-id="#quick-look" data-tooltip="tooltip" data-placement="top" title="Quick View">
                                                <i class="fas fa-search-plus"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a data-modal="modal" href="../page/addpanier.php?id=<?=$produitPopu[$i]['id']?>" class="addPanier" data-modal-id="#add-to-cart" data-tooltip="tooltip" data-placement="top" title="Add to Cart">
                                                <i class="fas fa-plus-circle"></i>
                                            </a>
                                        </li>
                                        <li>

                                            <a href="../user/signin.php" data-tooltip="tooltip" data-placement="top" title="Add to Wishlist">
                                                <i class="fas fa-heart"></i>
                                            </a>
                                        </li>
                                        <li>

                                            <a href="../user/signin.php" data-tooltip="tooltip" data-placement="top" title="Email me When the price drops">
                                                <i class="fas fa-envelope"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div> -->
                            </div>
                            <div class="text-center" style="padding-top:1rem;">
                                <!-- <span class="product-o__category">
                                     <a href="../product/category.php?id=<?=$produitPopu[$i]['category']?>"><?=$category[0]['name']?></a>
                                </span> -->
                                <span class="product-o__name">
                                    <a style="color:rgba(0,0,0,0.5);font-size:0.9rem;" href="../product/content.php?id=<?= $produitPopu[$i]['id']?>"><?=$produitPopu[$i]['name']?></a></span>
                                <!-- <div class="product-o__rating gl-rating-style"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>
                                    <span class="product-o__review">(23)</span>
                                </div> -->
                                <span class="product-o__price" style="font-size:1rem;"><?=$produitPopu[$i]['price']?>
                                <!-- <span class="product-o__discount"><?=$produitPopu[$i]['price']?></span> -->
                                F
                                                <a href="../page/addpanier.php?id=<?=$produitPopu[$i]['id']?>" data-modal="modal" data-modal-id="#add-to-cart" data-tooltip="tooltip" class="addPanier" data-placement="top" title="Add to Cart">
                                                    <i class="fas fa-plus-circle" style="color:green"></i>
                                                </a>    
                                </span>
                            </div>
                        </div>
                    </div>
                    <?php endfor ;?>
                    <!-- <div class="col-lg-12">
                        <div class="load-more">

                            <button class="btn btn--e-brand" type="button">Load More</button></div>
                    </div>         -->
                </div>
            </div>
        
        </div>
    </div>
</div>