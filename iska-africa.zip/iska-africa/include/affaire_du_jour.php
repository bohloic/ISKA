
            <!--====== Section 3 ======-->
            <div class="u-s-p-b-5 mt-5 mb-5">

                <!--====== Section Intro ======-->
                <div class="section__intro u-s-m-b-20">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="section__text-wrap">
                                    <h1 class="section__heading u-c-secondary u-s-m-b-12">L'AFFAIRE DU JOUR</h1>

                                    <span class="section__span u-c-silver">ACHETEZ L'OFFRE DU JOUR, DÉPÊCHEZ-VOUS ! CES NOUVEAUX PRODUITS EXPIRERONT BIENTT.</span>

                                    <span class="section__span u-c-silver">AJOUTEZ-LES DANS VOTRE PANIER.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Intro ======-->


                <!--====== Section Content ======-->
                <div class="section__content ptiAnime" >
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6 col-xs-6 u-s-m-b-30 left" data-slide>
                                <div class="product-o product-o--radius product-o--hover-off u-h-100">
                                    <div class="product-o__wrap">

                                        <a class="aspect aspect--bg-grey aspect--square u-d-block" href="../product/content.php">

                                            <img class="aspect__img" src="../images/product/electronic/7.jpg" alt=""></a>
                                        <div class="product-o__special-count-wrap">
                                            <div class="countdown countdown--style-special" data-countdown="2020/05/01"></div>
                                        </div>
                                        <div class="product-o__action-wrap">
                                            <ul class="product-o__action-list">
                                                <li>

                                                    <a data-modal="modal" data-modal-id="#quick-look" data-tooltip="tooltip" data-placement="top" title="Quick View"><i class="fas fa-search-plus"></i></a></li>
                                                <li>

                                                    <a data-modal="modal" data-modal-id="#add-to-cart" data-tooltip="tooltip" data-placement="top" title="Add to Cart"><i class="fas fa-plus-circle"></i></a></li>
                                                <li>

                                                    <a href="../signin.html" data-tooltip="tooltip" data-placement="top" title="Add to Wishlist"><i class="fas fa-heart"></i></a></li>
                                                <li>

                                                    <a href="../signin.html" data-tooltip="tooltip" data-placement="top" title="Email me When the price drops"><i class="fas fa-envelope"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="text-center" style="padding-top:1rem;">
                                        <!-- <span class="product-o__category">

                                            <a href="../product/category.php">Electronics</a></span> -->

                                        <span class="product-o__name">

                                            <a style="color:rgba(0,0,0,0.5);font-size:0.9rem;"  href="../product/content.php">DJI Phantom Drone 4k</a></span>
                                        <!-- <div class="product-o__rating gl-rating-style"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>

                                            <span class="product-o__review">(2)</span></div> -->

                                        <span class="product-o__price">150000F

                                            <!-- <span class="product-o__discount">$160.00</span> -->
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class=" col-sm-6 col-xs-6 u-s-m-b-30 right" data-slide>
                                <div class="product-o product-o--radius product-o--hover-off u-h-100">
                                    <div class="product-o__wrap">

                                        <a class="aspect aspect--bg-grey aspect--square u-d-block" href="../product/content.php">

                                            <img class="aspect__img" src="../images/product/electronic/product12.jpg" alt=""></a>
                                        <div class="product-o__special-count-wrap">
                                            <div class="countdown countdown--style-special" data-countdown="2020/05/01"></div>
                                        </div>
                                        <div class="product-o__action-wrap">
                                            <ul class="product-o__action-list">
                                                <li>

                                                    <a data-modal="modal" data-modal-id="#quick-look" data-tooltip="tooltip" data-placement="top" title="Quick View"><i class="fas fa-search-plus"></i></a></li>
                                                <li>

                                                    <a data-modal="modal" data-modal-id="#add-to-cart" data-tooltip="tooltip" data-placement="top" title="Add to Cart"><i class="fas fa-plus-circle"></i></a></li>
                                                <li>

                                                    <a href="../signin.html" data-tooltip="tooltip" data-placement="top" title="Add to Wishlist"><i class="fas fa-heart"></i></a></li>
                                                <li>

                                                    <a href="../signin.html" data-tooltip="tooltip" data-placement="top" title="Email me When the price drops"><i class="fas fa-envelope"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="text-center" style="padding-top:1rem;">
                                        <!-- <span class="product-o__category">

                                            <a href="../product/category.php">Electronics</a></span> -->

                                        <span class="product-o__name">

                                            <a style="color:rgba(0,0,0,0.5);font-size:0.9rem;" href="../product/content.php">DJI Phantom Drone 2k</a></span>
                                        <!-- <div class="product-o__rating gl-rating-style"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>

                                            <span class="product-o__review">(2)</span></div> -->

                                        <span class="product-o__price" style="font-size:1rem;">10000F

                                            <!-- <span class="product-o__discount">$160.00</span> -->
                                        </span>
                                    </div>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 3 ======-->