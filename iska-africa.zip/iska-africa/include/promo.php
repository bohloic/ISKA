<?php 
require_once dirname(__DIR__).SP.'DB.php';
try{
    //driver non trouver mais ça marche; A revoir...
     $data = new DB('mysql','localhost', 'root', '','iska-africa');
    if($data){
        $catProd= $data->section_promo(3,5,9);
        // var_dump($catProd);
    }
}catch(PDOException $e) {     
    die("Error: ".$e->getMessage()); 
}

?>

<div class="u-s-p-y-5 mt-5 mb-5 ">
    <div class="section__content ">
        <div class="container">
            <div class="row">
                <?php for($i=0; $i<3;$i++): ?>
                <div class="col-lg-4 col-md-6 col-sm-6 " >
                    <div class="column-product container pt-3 pb-3">
                        <span class="column-product__title u-c-secondary u-s-m-b-25 text-xl text-center"> <?= strtoupper($catProd[$i][0]['name'])?></span>
                        <ul class="column-product__list ">

                        <?php for($k=0; $k < count($catProd[$i]) ;$k++): ?>    
                            <?php if($k<3) : ?>
                                <li class="column-product__item">
                                    <div class="product-l" >
                                        <div class="product-l__img-wrap">        
                                            <a class="aspect  aspect--square u-d-block product-l__link" href="../product/content.php?id=<?=  $catProd[$i][$k]['id']?>">
                                            <img class="aspect__img" src="../<?=  $catProd[$i][$k]['image']?>" alt=""></a>
                                        </div>
                                        <div class="product-l__info-wrap text-center" style="padding-top:1rem;">            
                                            <!-- <span class="product-l__category">            
                                                    <a href="../product/category.php?id=<?=$catProd[$i][$k]['category']?>"> <?= $catProd[$i][$k]['name']?></a></span>             -->
                                            <span class="product-l__name">            
                                                    <a style="color:rgba(0,0,0,0.5);font-size:0.9rem;" href="../product/content.php?id=<?=$catProd[$i][$k]['0']?>"> <?= $catProd[$i][$k]['2']?></a></span>            
                                            <span class="product-l__price" style="font-size:1rem;"> <?= $catProd[$i][$k]['price']?> F
                                            <!-- <span class="product-l__discount">$160</span> -->
                                            <span >
                                                <a href="../page/addpanier.php?id=<?= $catProd[$i][$k]['id']?>" data-modal="modal" data-modal-id="#add-to-cart" data-tooltip="tooltip" class="addPanier" data-placement="top" title="Add to Cart">
                                                    <i class="fas fa-plus-circle" style="color:green"></i>
                                                </a>
                                            </span>
                                            
                                            </span>
                                        </div>
                                    </div>
                                </li> 
                            <?php endif; ?>

                        <?php endfor; ?>
                        </ul>
                    </div>
                </div>
                <?php endfor;?>
            </div>
        </div>
    </div>
                            </div>
    <!--====== End - Section Content ======-->
</div>

