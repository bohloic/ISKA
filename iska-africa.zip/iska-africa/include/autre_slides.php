
<!--====== Section 7 ======-->
<div class="u-s-p-y-90 mt-5 mb-5">

    <!--====== Section Content ======-->
    <div class=" ptiAnime">
        
            <div class="container ">
                <div class="row ">
                    <div class="col-lg-4 col-md-4 col-sm-6 u-s-m-b-30 left">

                        <!-- <a class="promotion" href="../product/category.php?id=<?=$produit[$i]['idCat']?>" > -->
                            <div class="aspect aspect--bg-grey aspect--square">

                                <img class="aspect__img promotion__img" src="../images/promo/2.jpg" alt=""></div>
                            <div class="promotion__content">
                                <div class="promotion__text-wrap">
                                    <div class="promotion__text-1">

                                        <span class="u-c-secondary">ACCESSORIES FOR YOUR EVERYDAY</span></div>
                                    <div class="promotion__text-2">

                                        <span class="u-c-secondary">GET IN</span>

                                        <span class="u-c-brand">TOUCH</span></div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 u-s-m-b-30">

                        <!-- <a class="promotion" href="../product/category.php?id=<?=$produit[$i]['idCat']?>"> -->
                            <div class="aspect aspect--bg-grey aspect--square">

                                <img class="aspect__img promotion__img" src="../images/promo/31.jpg" alt=""></div>
                            <div class="promotion__content">
                                <div class="promotion__text-wrap">
                                    <div class="promotion__text-1">

                                        <span class="u-c-secondary">SMARTPHONE</span>

                                        <span class="u-c-brand">2019</span></div>
                                    <div class="promotion__text-2">

                                        <span class="u-c-secondary">NEW ARRIVALS</span></div>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-4 col-md-4 col-sm-6 u-s-m-b-30">

                        <!-- <a class="promotion" href="../product/category.php?id=<?=$produit[$i]['idCat']?>"> -->
                            <div class="aspect aspect--bg-grey aspect--square">

                                <img class="aspect__img promotion__img" src="../images/product/electronic/15.jpg" alt=""></div>
                            <div class="promotion__content">
                                <div class="promotion__text-wrap">
                                    <div class="promotion__text-1">

                                        <span class="u-c-secondary">DSLR FOR NEW GENERATION</span></div>
                                    <div class="promotion__text-2">

                                        <span class="u-c-brand">GET UP TO 10% OFF</span></div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        
    <!--====== End - Section Content ======-->
    </div>
<!--====== End - Section 7 ======-->
</div>