<!--====== Main App ======-->
<?php 
$pays = [
    'Maroc',
    'Cote d\'ivoire',
    'Angola',
    'Benin',
    'Nigeria',
    'Kenya',
    'RDC',
    'Conakry',
    'Senegal',
];
?>
  <!--====== Section 12 ======-->
            
  

<!--====== Brand Slider ======-->
<div class=" mt-2 mb-2" style="width:100%">
    <div class="row pays ">
        
        <?php for($i=0; $i<count($pays);$i++): ?>            
            <div class="col-md-1 col-sm-2 col-xs-3  pays-box">
                <a class="orange" type="button" href=""><?= $pays[$i]; ?></a>
            </div>
    <?php endfor; ?>
    </div>
            
</div>
<!--====== End - Brand Slider ======-->
                 