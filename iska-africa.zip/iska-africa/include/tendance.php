<?php

if($data){
    $topTendance=$data->top_tendance();    
    $sousCat = $data->query('SELECT * FROM sous_category');
}
?>

    <div class="u-s-p-b-5 mb-5">

    <!--====== Section Intro ======-->
        <div class="section__intro u-s-m-b-16">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section__text-wrap">
                            <h1 class="section__heading u-c-secondary u-s-m-b-12">TOP TENDANCE</h1>

                            <span class="section__span u-c-silver">CHOISIR LA CATÉGORIE</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--====== End - Section Intro ======-->


        <!--====== Section Content ======-->
        <div class="section__content">
            <div class="container">
                
                        <div class="filter-category-container">
                            <div class="filter__category-wrapper">
                                <button class="btn filter__btn filter__btn--style-1 js-checked" type="button" data-filter="*">TOUTES</button>
                            </div>
                            <?php for($i=0; $i < 4; $i++) : ?>
                            <div class="filter__category-wrapper">
                                <button class="btn filter__btn filter__btn--style-1" type="button" data-filter=".<?= $sousCat[$i]['name'] ?>"><?= strtoupper($sousCat[$i]['name']) ?></button>
                            </div>
                            <?php endfor ;?>

                        </div>

                        
                        <div class="row filter__grid-wrapper u-s-m-t-5">
                            <div class="" >

                                <?php for($k=0; $k < 8; $k++) : ?>
                                <?php if($k<8) : ?>
                                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6 filter__item <?= $topTendance[$k]['sous_cat']?>">
                                    <div class="product-o product-o--hover-on product-o--radius" style="width: 20%; min-width: 200px;">
                                        <div class="product-o__wrap">

                                            <a class="aspect aspect--bg-grey aspect--square u-d-block" href="../product/content.php?id=<?=  $topTendance[$k]['id']?>">

                                                <img class="aspect__img" src="../<?= $topTendance[$k]['img']?>" alt=""></a>
                                            <!-- <div class="product-o__action-wrap">
                                                <ul class="product-o__action-list">
                                                    <li>                                                
                                                        <a class="addPanier" href="../page/addpanier.php?id=<?= $topTendance[$k]['id']?>" data-modal="modal" data-modal-id="#add-to-cart" data-tooltip="tooltip" data-placement="top" title="Add to Cart">
                                                            <i class="fas fa-plus-circle"></i>
                                                        </a>
                                                    </li>
                                                    
                                                </ul>
                                            </div> -->
                                        </div>
                                        <div class="text-center" style="padding-top:1rem;">
                                            <!-- <span class="product-o__category">

                                                <a href="../product/category.php?id=<?=$topTendance[$k]['idCat']?>"><?= $topTendance[$k]['cat'] ?></a></span> -->

                                            <span class="product-o__name">

                                                <a style="color:rgba(0,0,0,0.5);font-size:0.9rem;" href="../product/content.php?id=<?=  $topTendance[$k]['id']?>"><?= $topTendance[$k]['prod']?></a></span>
                                            <!-- <div class="product-o__rating gl-rating-style"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>

                                                <span class="product-o__review">(23)</span></div> -->

                                            <span class="product-o__price" style="font-size:1rem;"><?= $topTendance[$k]['prix']?> F

                                                <!-- <span class="product-o__discount"><?= $topTendance[$k]['prod']?></span> -->
                                            <!-- </span>
                                            <span > -->
                                                <a href="../page/addpanier.php?id=<?= $topTendance[$k]['id']?>" data-modal="modal" data-modal-id="#add-to-cart" data-tooltip="tooltip" class="addPanier" data-placement="top" title="Add to Cart">
                                                    <i class="fas fa-plus-circle" style="color:green"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <?php endif ;?>
                                <?php endfor ;?>                                
                            </div>                            
                        </div>                        
                        <div class="orange text-center"><a class="btn btn--e-brand" type="button" href="../product/categories.php">Voir Plus</a> </div>                               
                    
            </div>

        </div>
            <!--====== End - Section Content ======-->
    </div>