<?php
class Client{
    const LIMIT_NOM = 3;
    const LIMIT_PRE = 5;
    const LIMIT_EMAIL = 8;
    const LIMIT_NOMB = 3;
    const LIMIT_MDP = 8;

    private $nom;
    private $prenom;
    private $email;
    private $nomb;
    private $typeclt;
    private $mdp;
    private $re_mdp;
    private $sex;
    private $dat_naiss;
    private $data;

    public function __construct($data = null, $nom = null, $prenom= null, $email= null, 
    $nomb= null, $typeclt= null, $mdp= null, $re_mdp= null, $sex= null, $dat_naiss= null)
    {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->email = $email;
        $this->nomb = $nomb;
        $this->typeclt = $typeclt;
        $this->mdp = $mdp;
        $this->re_mdp = $re_mdp;
        $this->sex = $sex;
        $this->dat_naiss = $dat_naiss;
        $this->data = $data;
    }
    
   

    public function isValid():bool
    {
        return empty($this->getErrors());
    }

    public function getErrors():array
    {
        $errors= [];
        $existe = $this->data->query("SELECT * FROM `client` WHERE email = '".$this->email."' ");
        if(strlen($this->nom) < self::LIMIT_NOM )
        {
            $errors['nom']= 'Votre nom est trop court';
        }
        if(strlen($this->prenom) < self::LIMIT_PRE )
        {
            $errors['prenom']= 'Votre prénom est trop court';
        }
        if(strlen($this->email) < self::LIMIT_EMAIL )
        {
            $errors['email']= 'Votre email est trop court';
        }
            
        if($existe) 
        {
            $errors['email']= 'Ce mail existe déja, veuillez saisir une adresse valide';
        } 
               
        if(strlen($this->nomb) < self::LIMIT_NOMB )
        {
            $errors['nomb']= 'Votre nom de la boutique  est trop court';
        }
        if($this->typeclt === '0' )
        {
            $errors['typeclt']= 'Choix incorrect';
        }
        if(strlen($this->mdp) < self::LIMIT_MDP )
        {
            $errors['mdp']= 'Votre mots de passe est trop court';
        }
        if(($this->re_mdp === '') || ($this->mdp !== $this->re_mdp)  )
        {
            $errors['re_mdp']= 'Mots de passe incorrect';
        }
        
        return $errors;
    }

    public function inscription($nom, $prenom, $email, $nomb, $typeclt, $mdp)
    {
        $mdp= password_hash($mdp, PASSWORD_DEFAULT);
        $save = $this->data->query("INSERT INTO `client` (`id`, `nom`, `prenom`, `nom_boutique`, `pays`, `email`, `statut`, `tel`, `password`, `avatar`)
            VALUES (NULL, :nom, :prenom, :nomb, NULL, :email , :typeclt, NULL, :mdp, '')",
            [
                'nom' => htmlentities($nom), 
                'prenom' => htmlentities($prenom),
                'email' => htmlentities($email), 
                'nomb' => htmlentities($nomb), 
                'typeclt' => htmlentities($typeclt), 
                'mdp' => htmlentities($mdp)
            ]
        );        
    }

    public function update_profil($nom,$prenom,$sex =null,$dat_naiss = null)
    {
        $update = $this->data->query("UPDATE `client` SET `nom`=' $nom',
        `prenom`=' $prenom',`sex`=' $sex',`dat_naiss`= ' $dat_naiss ' WHERE id=1");
    }

    // public function login($email,$mdp)
    // {
    //     $controle = $this->query("SELECT id FROM  client WHERE email LIKE '%".$emai."%' AND password LIKE '%".$password."%' ");

    // }   

    // public function testadd()
    // {
    //     try{
    //         $data = new DB();
    //        if($_SERVER["REQUEST_METHOD"]=="POST")
    //        {
    //            if(isset($_POST)){
    //            $nom=mysqli_real_escape_string($data,$_POST['nom']);
    //            $prenom=mysqli_real_escape_string($data,$_POST['prenom']);
    //            $boutique=mysqli_real_escape_string($data,$_POST['nomb']);
    //            $password=mysqli_real_escape_string($data,$_POST['password']);
           
    //            $sql="SELECT id FROM client WHERE nom='$nom' and prenom='$prenom' and nom_boutique='$boutique' and password='$password'";
    //            $result=mysqli_query($data,$sql);
    //            $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
    //            $active=$row['active'];
           
    //            $count=mysqli_num_rows($result);
    //            if($count ==1){
    //                $sessio=register("nom");
    //                $_SESSION['login_user']=$nom;
           
    //                header("location:dashboard.php");
    //            }else{
    //                $error="Votre nom de connexion et de mot de passe est incorrect";
    //            }
    //        }
    //        }
    //        }catch(PDOException $e) {     
    //            die("Error: ".$e->getMessage()); 
    //        }
    // }
}