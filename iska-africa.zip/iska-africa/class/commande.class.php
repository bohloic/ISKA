<?php
class Command{

    private $id_client;
    private $data;

    public function __construct($data = null, $id_client = null)
    {
        $this->id_client = $id_client;
        $this->data = $data;
    }

    public function newCommande($panier)
    {
        $date = new DateTime();
        $datee = $date->format('Y-m-d');
        $heure= $date->format('H:i:s');
        $this->data->query("INSERT INTO `bon_commande`(`date`,`heure`, `client`, `statut`) 
                            VALUES ('".$datee."' ,'".$heure."' , ".$this->id_client.", 'traitement')");
        $id_Bcde= $this->data->query("SELECT id FROM bon_commande");
        $id_Bcde = array_reverse($id_Bcde);

        foreach($panier as $prod => $qte){
            $this->data->query("INSERT INTO `commander`(`product`,`bon_commande`, `quantite`) 
            VALUES (".$prod.",".$id_Bcde[0]['id'].",".$qte.")");
        }
    }

    public function total($id)
    {
        $total = 0;
        $products = $this->data->query("SELECT commander.quantite AS qte , 
        product.price as prix FROM `commander` ,product 
        WHERE commander.product = product.id  and commander.bon_commande = ".$id." "); 
        foreach($products as $product){
            $total += $product['prix'] * $product['qte'];
        }
        return $total;
    }








}