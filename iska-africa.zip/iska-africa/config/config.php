<?php
    define("DB_USER","root");
    define("DB_PASSWORD","");
    define("HOST", "localhost");
    define("DB_NAME", "iska-africa");


?>