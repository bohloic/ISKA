<?php
require_once dirname(__DIR__).DIRECTORY_SEPARATOR.'functions/auth.php';
require_once dirname(__DIR__).DIRECTORY_SEPARATOR.'DB.php';
require_once dirname(__DIR__).DIRECTORY_SEPARATOR.'class/panier.class.php';
require_once dirname(__DIR__).DIRECTORY_SEPARATOR.'class/client.class.php';
require_once dirname(__DIR__).DIRECTORY_SEPARATOR.'class/commande.class.php';
require_once dirname(__DIR__).DIRECTORY_SEPARATOR.'functions/functions.php';
require_once dirname(__DIR__).DIRECTORY_SEPARATOR.'config/config.php';
$data = new DB();
$panier = new panier($data);
$userCo = new Client();
?>