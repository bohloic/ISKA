<?php
require_once '_header.php';
$extention="../page/";
if(isset($index)){
    $extention="";
}
?>
<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
    <meta charset="UTF-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge"><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../images/logo/logo.jpg" rel="shortcut icon">
    <title>Iska-Africa - Electronics, Apparel, Computers, Books, DVDs & more</title>

    <!--====== Google Font ======-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">

    <!-- bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <!--====== Vendor Css ======-->
    <link rel="stylesheet" href="../css/vendor.css">

    <!--====== Utility-Spacing ======-->
    <link rel="stylesheet" href="../css/utility.css">

    <!--====== App ======-->
    <link rel="stylesheet" href="../css/app.css">

    <!-- categorie avec hover -->
    <link rel="stylesheet" href="../css/menuHover.css">

    <style>
        :root{
            --orange : rgb(255,69,0);
        }
        
       body
       {
           margin: 0px 0px;
       }
        
        .menu  
        {
            background: green; 
            position: relative;
        } 

        .menu form
        {
            display: flex;
            float:middle;
        }

        

        .menu form button
        {
            margin-left:0.2rem;
            background: white;
            width: 2rem;
        }
        
        /* .menu ul 
        {
            float:right;
        } */

        .menu ul li
        {
            margin-right:0.5rem;
        }

        .menu ul li:hover
        {
            background-color: rgba(255,255,255,0.5);
            border-radius:5px;
        }

        

        
        

        .menu i{
            color: white;
        }

        

        .sidebar
        {
            position: relative;
            /* height: 2340px; */
            width: 20%;
            padding: 0 20px;
            float: left;
            position: relative;
        }

        .sidenav {
        /* width: 15%; */
        /* position: fixed; */
        /* z-index: 1;
        top: 125px;
        left: 10px; */
        background: #eee;
        /* overflow-x: hidden; */
        padding: 8px 0;
       
        }

        .cat-main
        {
            width: 85%;
        }
        
        .horizontal-line
        {            
            height: 0.20rem;
            width: 50%;
            background-color: var(--orange) ;
            margin-left :25%;
            margin-bottom : 2rem;
            border-radius: 5px;
        }

        .orange 
        {
            color: var(--orange);
        }
        
        

        Footer{
            background-color:#000;
            color:white;
        }

        footer  ul
        {
            list-style: none;
        }

        footer ul li a
        {
            padding-right: 1rem;
            color:white;
        }


        

        .mon-container 
        {
            margin-left :25%;
        }

        .center 
        {
            margin-left:10%;
            margin-top: 10%;
        }

        

        .pays
        {
            height:auto;
            display: flex;
            margin: 0px auto;
        }

        .pays .pays-box 
        {
            margin-left:2rem;
            width: 100px;

            
        }
        .pays .pays-box a
        {
            text-decoration : none;
            color : gray;
            text-align : center;
            border: 1px solid gray;
            border-radius :10px;
            width: 100px;
        }

        .pays .pays-box a:hover 
        {
            background: var(--orange);
            color:white;
        }

        .panier
        {
            color:white;
            border:1px solid red;
        }

        .panier span
        {
            border:1px solid blue;
        }

        
        
        /* animation */
       
        .ptiAnime
    {
        width:100%;
        
    }

    .ptiAnime .left
    {    
        animation: slideLeft 6s ; 
        float:left;
    }

    .ptiAnime .right 
    {
        animation: slideRight 6s ; 
        float:right;
    }
    
    @keyframes slideLeft {
        from {
            transform: translateX(-700px)
        }
        to {
            transform: translateX(0)
        }
    }

    @keyframes slideRight {
        from {
            transform: translateX(700px)
        }
        to {
            transform: translateX(0)
        }
    }

    </style>
</head>
<body class="config">
    <div class="preloader is-active">
        <div class="preloader__wrap">

            <img class="preloader__img" src="../images/preloader.png" alt=""></div>
    </div>

    <!--====== Main App ======-->
    <div id="app">

        <!--====== Main Header ======-->
        <header >     

        <!--====== Menu Pays ======-->
        <?php require_once '../include/menu_pays.php'; ?>
        <!--====== End - Menu Pays ======--> 

            <?php require_once '../include/menu_top.php'; ?>
            
        </header>
        <!--====== End - Main Header ======-->