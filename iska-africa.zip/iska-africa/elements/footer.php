<?php
$product = $data->query("SELECT image,name,price FROM product WHERE id= 5"); 
$nbr = $panier->count() + 1;
?>

</div>
        <!--====== End - App Content ======-->

<footer style="padding-top:2rem;">
        
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <ul>
                            <li>
                                <h2>Contact </h2>
                            </li>
                            <li>
                                <i class="fas fa-home"></i>
                                Abidjan , Cocody, Riviera palmeraie
                            </li>
                            <li>
                                <i class="fas fa-phone-volume"></i>
                                (+225) 05 55 48 55 55 
                            </li>
                            <li>
                                <i class="far fa-envelope"></i>
                                info@iska.biz
                            </li>
                            <li>
                                <a  href="#"><i class="fab fa-facebook-f"></i></a>                                
                                <a  href="#"><i class="fab fa-twitter"></i></a>                                
                                <a  href="#"><i class="fab fa-youtube"></i></a>                                
                                <a  href="#"><i class="fab fa-instagram"></i></a>                                
                                <a  href="#"><i class="fab fa-google-plus-g"></i></a>
                            </li>
                        </ul>
                        
                    </div>
                    <div class="col-lg-3 col-md-6">    
                        <ul>
                            <li>
                                <h2 >Information</h2>
                            </li>
                            <li>
                                <a href="index.php">Accueil</a>
                            </li>

                            <li>
                                <a href="index.php">produit</a>
                            </li>
                                
                            <li>
                                <a href="../product/categories.php">Categorie</a>
                            </li>

                            <li>
                                <a href="user/dashboard.php">Compte</a>
                            </li>
                        </ul>                        
                    </div>
                    <div class="col-lg-5 col-md-12">                        

                        <h2 >Rejoignez notre bulletin</h2>
                        <form class="form-group">
                            <div class="u-s-m-b-15">
                                <div class="form-check">

                                    <input class="form-check-input" type="radio"  name="homme">
                                    <label  for="homme">Homme</label>
                                </div>
                                <div class="form-check">

                                    <input class="form-check-input" type="radio" name="femme">
                                    <label  for="femme">Femme</label>
                                </div>
                            </div>
                            <div class="u-s-m-b-15">

                                <input  class="form-control" type="text" placeholder="Entrer votre Email">

                                <button class="btn btn--e-brand-b-2"  type="submit">S'ABONNER</button></div>

                            <span >Abonnez-vous à la liste de diffusion pour recevoir des mises à jour sur les promotions, les nouveautés, les remises et les coupons.</span>
                        </form>
                        
                    </div>
                    <div class="text-center">

                        <span>Copyright © 2021</span>

                        <a href="index.php" class="orange">Iska-Africa</a>

                        <span>Tous droits réservés</span>
                        
                    </div>
                </div>
            </div>
        
    </footer>
    
<!-- add to card modal -->
    <div class="modal fade" id="add-to-cart" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content modal-radius modal-shadow">

                <button class="btn dismiss-button fas fa-times" type="button" data-dismiss="modal"></button>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-6 col-md-12">
                            <div class="success u-s-m-b-30">
                                <div class="success__text-wrap"><i class="fas fa-check"></i>

                                    <span>L'article a été ajouté avec succès!</span></div>
                                <div class="success__img-wrap">
                                   

                                    <img class="u-img-fluid" src="../<?= $product[0]['image'] ?>" alt=""></div>
                                <div class="success__info-wrap">

                                    <span class="success__name"><?= $product[0]['name'] ?></span>

                                    <span class="success__quantity">Quantité: 1</span>

                                    <span class="success__price"><?= $product[0]['price'] ?> F</span></div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div class="s-option">
                                <span class="s-option__text"><span id="countL"></span> article<?= $panier->count()>1 ? 's' : ''; ?> dans votre panier</span>
                                <div class="s-option__link-box">

                                    <a class="s-option__link btn--e-white-brand-shadow" data-dismiss="modal">CONTINUER VOS ACHATS</a>

                                    <a class="s-option__link btn--e-white-brand-shadow" href="../page/cart.php">VOIR PANIER</a>

                                    <form action="addcommande.php" method="post" >
                                        <a class="s-option__link btn--e-brand-shadow"  name="submit"> PASSER À LA CAISSE</a>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- end - add to card modal-->


    <!--====== Newsletter Subscribe Modal ======-->
    <div class="modal fade new-l" id="newsletter-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content modal--shadow">

                <button class="btn new-l__dismiss fas fa-times" type="button" data-dismiss="modal"></button>
                <div class="modal-body">
                    <div class="row u-s-m-x-0">
                        <div class="col-lg-6 new-l__col-1 u-s-p-x-0">

                            <a class="new-l__img-wrap u-d-block" href="shop-side-version-2.php">

                                <img class="u-img-fluid u-d-block" src="../images/newsletter/1.jpg" alt=""></a></div>
                        <div class="col-lg-6 new-l__col-2">
                            <div class="new-l__section u-s-m-t-30">
                                <div class="u-s-m-b-8 new-l--center">
                                    <h3 class="new-l__h3">Bulletin</h3>
                                </div>
                                <div class="u-s-m-b-30 new-l--center">
                                    <p class="new-l__p1">Inscrivez-vous pour recevoir des e-mails pour obtenir le scoop sur les nouveaux arrivages, les ventes spéciales et plus encore.</p>
                                </div>
                                <form class="new-l__form">
                                    <div class="u-s-m-b-15">

                                        <input class="news-l__input" type="text" placeholder="E-mail Address"></div>
                                    <div class="u-s-m-b-15">

                                        <button class="btn btn--e-brand-b-2" type="submit">S'inscrire!</button></div>
                                </form>
                                <div class="u-s-m-b-15 new-l--center">
                                    <p class="new-l__p2">En vous inscrivant, vous acceptez de recevoir les offres Reshop,
promotions et autres messages commerciaux. Vous pouvez vous désinscrire à n'importe quel moment.</p>
                                </div>
                                <div class="u-s-m-b-15 new-l--center">

                                    <a class="new-l__link" data-dismiss="modal">Non merci</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--====== End - Newsletter Subscribe Modal ======-->
    <!--====== End - Modal Section ======-->
</div>
<!--====== End - Main App ======-->


<!--====== Google Analytics: change UA-XXXXX-Y to be your site's ID ======-->
<script>
    window.ga = function() {
        ga.q.push(arguments)
    };
    ga.q = [];
    ga.l = +new Date;
    ga('create', 'UA-XXXXX-Y', 'auto');
    ga('send', 'pageview')
</script>

<!--====== Vendor Js ======-->
<script src="../js/vendor.js"></script>

<!--====== jQuery Shopnav plugin ======-->
<script src="../js/jquery.shopnav.js"></script>

<!--====== App ======-->
<script src="../js/app.js"></script>
<script src="../js/app1.js"></script>
<script src="../js/category.js"></script>

<!--====== Noscript ======-->
<noscript>
    <div class="app-setting">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="app-setting__wrap">
                        <h1 class="app-setting__h1">JavaScript is disabled in your browser.</h1>

                        <span class="app-setting__text">Please enable JavaScript in your browser or upgrade to a JavaScript-capable browser.</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</noscript>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="../js/panier.js"></script>
<!--====== end of Footer ======-->
</body>
</html>