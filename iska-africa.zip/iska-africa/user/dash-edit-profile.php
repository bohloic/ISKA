<?php
session_start();
// var_dump($_FILES);

?>
<?php if(isset($_SESSION['user']['profil'])): ?>
    <?php 
        unset($_SESSION['user']['profil']);
        header("Location: http://localhost/iska/user/dashboard.php");
        exit; 
    ?>
<?php else :?>
    <?php   
        require "../functions/auth.php";
        force_user(); 
        require_once '../elements/header.php';
        $email = htmlentities($_SESSION['email']);
        $client = $data->query("SELECT * FROM `client` WHERE email = '$email' ");
        $errors = null;
        if(isset($_POST['nom'],$_POST['prenom'])){
            if(strlen($_POST['nom'])>3 && strlen($_POST['prenom'])>5){
                echo "yes";
                $nom = htmlentities($_POST['nom']);
                $prenom = htmlentities($_POST['prenom']);
                if(isset($_POST['sex'])){
                    $sex = htmlentities($_POST['sex']);
                    $update = $data->query("UPDATE `client` SET`sex`='$sex' WHERE email ='$email'");

                }
                if(isset($_POST['j'],$_POST['m'],$_POST['y'])){
                    $birth = htmlentities($_POST['y']).'-'.htmlentities($_POST['m']).'-'.htmlentities($_POST['j']);   
                    $update = $data->query("UPDATE `client` SET `dat_naiss`='$birth' WHERE email ='$email'");         
                }
                $update = $data->query("UPDATE `client` SET `nom`='$nom',`prenom`='$prenom' WHERE email ='$email'");
                $_SESSION['user']['profil']=true;
                // $_SESSION
                // var_dump($_SESSION);
            }else{
                if(strlen($_POST['nom'])<3){
                    $errors['nom'] = "le nom est trop court";             
                }

                if(strlen($_POST['prenom'])<3){
                    $errors['prenom'] = "le prenom est trop court";             
                }
            }
            // echo "yes";
        }



        
        if(isset($_FLILES['avatar']) AND !empty($_FILES['avatar']['name'])){
            $taillevalid=2097152;
            $extensioovalid=array('jpg','png','jpeg');
            if($_FILES['avatar']['size']<=$taillevalid)
            {
            $extenssionuplad=strtolower(substr(strrchr($_FILES['avatar']['name'],'.'),start()));
            if(in_array($extenssionuplad,$extensioovalid))
            {
            if(isset($_POST['submit'])){
                $fileName=$_FILES['avatar']['name'];
                $fileExt=".".strtolower(substr(strrchr($fileName,'.'),1));
                if(!in_array($fileExt,$extensioovalid)){
                echo "le fichier n'est pas une image";
die;
                }
                $tmpName=$_FILES['avatar']['name'];
                $uniqueName=md5(uniqid(rand(),true));
                $fileName="./membre/avatar/".$uniqueName.$fileExt;
                $resultat=move_uploaded_file($tmpName,$fileName);
                if($resultat){
                    echo "Transfert terminé";
                }
            }
                // $fichier = "/membre/avatar/";
                // move_uploaded_file($_FILES['avatar']['tmp_name'],$fichier);
                //     echo 'fichier envoyé';
                //     $temp=$_FILES['tmp_name'];
                //     $name=$_FILES['name'];
                //     $namefichier= $fichier.$_FILES['avatar']['name'];
                //     $req = $data->query("UPDATE `client` SET `avatar`='$namefichier' WHERE email ='$email' ");
                //     var_dump($fichier);
                // }else{
                //     echo "Votre photo de profile doit être au format jpg,jpeg,png";
                // }
                // $chemin="./membre/avatar/".$_SESSION['id'].".".$extenssionuplad;
                // $fichier=basename($_FILES['avatar']['name']);
                // $resultat=move_uploaded_file($_FILES['avatar']['tmp_namme'],$chemin,$fichier);
                // if($resultat)
                // {
                //     echo"fichier envoyé avec succès";
                //     $updataavatar=$data->prepare("UPDATE client SET avatar=:avatar WHERE id=:id");
                //     $updataavatar->execute(array(
                //         'avatar'=>$_SESSION['id'].".".$extenssionuplad,
                //         'id'=>$_SESSION['id']
                //     ));
                // }else{
                //     $msg="Erreur durant l'importaton de la photo";
                // } 
            }else
            {
                $msg="Votre photo de profile doit être au format jpg,jpeg,png";
            }
            }else
            {
             $msg="votre photo de profile ne doit pas depasser 2 Mo";   
            }
    }
//     var_dump($fichier);
// var_dump($chemin);
// var_dump($resultat);
    ?>




        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Section 1 ======-->
            <div class="u-s-p-y-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="breadcrumb">
                            <div class="breadcrumb__wrap">
                                <ul class="breadcrumb__list">
                                    <li class="has-separator">

                                        <a href="index.php">Acceuil</a>
                                    </li>
                                    <li class="is-marked">

                                        <a href="dash-edit-profile.php">Mon compte</a>
                                    </li>
                                </ul>    
                                        
                                   
                                
                            </div>
                        </div>
                            
                        
                    </div>
                </div>
            </div>
            <!--====== End - Section 1 ======-->


            <!--====== Section 2 ======-->
            <div class="u-s-p-b-5">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="dash">
                        <div class="container">
                            <?php if(!empty($errors)): ?>
                                <div class="row row--center">
                                    <div class="col-lg-6 col-md-8 ">                                
                                        <div class="alert alert-danger">
                                            Formulaire invalide 
                                        </div>                                
                                    </div>
                                </div>
                            <?php endif ?>
                            <?php if(isset($_SESSION['user']['profil'])): ?>
                                <div class="row row--center">
                                    <div class="col-lg-6 col-md-8">                                
                                        <div class="alert alert-success">
                                            Modification enrégistrée
                                        </div>                                
                                    </div>
                                </div>
                            <?php endif ?>
                            <div class="row">
                                <div class="col-lg-3 col-md-12">
                                    
                                    <!--====== Dashboard Features ======-->
                                    <?php require_once 'menu-dash.php';?>
                                    <!--====== End - Dashboard Features ======-->
                                </div>
                                <div class="col-lg-9 col-md-12">
                                    <div class="dash__box dash__box--shadow dash__box--radius dash__box--bg-white">
                                        <div class="dash__pad-2">
                                            <h1 class="dash__h1 u-s-m-b-14">Editer Profile</h1>

                                            <span class="dash__text u-s-m-b-30">Il me semble que vous n'avez pas encore mis à jour votre profil</span>
                                            <div class="dash__link dash__link--secondary u-s-m-b-30">

                                                <a data-modal="modal" data-modal-id="#dash-newsletter">Souscrivez au journal</a></div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <form enctype="multipart/form-data" class="dash-edit-p"  method="post">
                                                        <div class="gl-inline">
                                                            <div class="u-s-m-b-30">

                                                                <label class="gl-label" for="reg-fname">Nom *</label>

                                                                <input class="input-text input-text--primary-style <?= isset($errors['nom']) ? 'is-invalid' : '' ?>" type="text" name="nom" placeholder="<?= $client[0]['nom'] ?>">
                                                                <?php if(isset($errors['nom'])): ?>
                                                                    <div class="invalid-feedback"><?= $errors['nom'] ?></div>
                                                                <?php endif ?>
                                                            </div>
                                                                
                                                                <div class="u-s-m-b-30">

                                                                    <label class="gl-label" for="reg-lname">Prenom *</label>

                                                                    <input class="input-text input-text--primary-style <?= isset($errors['prenom']) ? 'is-invalid' : '' ?>" type="text" name="prenom" placeholder="<?= $client[0]['prenom'] ?>">
                                                                    <?php if(isset($errors['prenom'])): ?>
                                                                        <div class="invalid-feedback"><?= $errors['prenom'] ?></div>
                                                                    <?php endif ?>
                                                                </div>
                                                        </div>
                                                        <div class="gl-inline">
                                                            <div class="u-s-m-b-30">

                                                                <!--====== Date of Birth Select-Box ======-->

                                                                <span class="gl-label">BIRTHDAY</span>
                                                                <div class="gl-dob">
                                                                    <select class="select-box select-box--primary-style" name="m">
                                                                        <option value="0">Mois</option>
                                                                        <option value="1">Janvier</option>
                                                                        <option value="2">Février</option>
                                                                        <option value="3">Mars</option>
                                                                        <option value="4">Avril</option>
                                                                        <option value="5">Mai</option>
                                                                        <option value="6">Juin</option>
                                                                        <option value="7">Juillet</option>
                                                                        <option value="8">Aout</option>
                                                                        <option value="9">Septembre</option>
                                                                        <option value="10">Octobre</option>
                                                                        <option value="11">Novembre</option>
                                                                        <option value="12">Décembre</option>
                                                                    </select>
                                                                    <select class="select-box select-box--primary-style" name="j">
                                                                        <option value="">Jour</option>
                                                                        <?php for($i=1; $i<32; $i++): ?>
                                                                            <?php if($i<9) :?>
                                                                                <option value="0<?= $i ?>">0<?= $i ?></option>
                                                                             <?php else: ?>
                                                                                <option value="<?= $i ?>"><?= $i ?></option>   
                                                                            <?php endif ?>
                                                                        <?php endfor;?>
                                                                    </select>
                                                                    <select class="select-box select-box--primary-style" name="y" >
                                                                        <option value="">Année</option>
                                                                        <?php for($i=2021; $i>1960; $i--): ?>
                                                                            <option value="<?= $i ?>"><?= $i ?></option>
                                                                        <?php endfor;?>
                                                                    </select></div>
                                                                <!--====== End - Date of Birth Select-Box ======-->
                                                            </div>
                                                            <div class="u-s-m-b-30">

                                                                <label class="gl-label" for="sex">GENRE</label>
                                                                <select class="select-box select-box--primary-style u-w-100" name="sex">
                                                                    <option value="0">Select</option>
                                                                    <option value="homme">Homme</option>
                                                                    <option value="femme">Femme</option>
                                                                </select></div>
                                                        </div>
                                                        <div class="gl-inline">
                                                            <div class="u-s-m-b-30">
                                                                <h2 class="dash__h2 u-s-m-b-8" >E-mail</h2>

                                                                <span class="dash__text"><?= $client[0]['email'] ?></span>
                                                                <div class="dash__link dash__link--secondary">

                                                                    <a href="#">Changer</a></div>
                                                            </div>
                                                            <div class="u-s-m-b-30">
                                                                <h2 class="dash__h2 u-s-m-b-8">Téléphone</h2>

                                                                <span class="dash__text">svp entrer votre numero de telephone</span>
                                                                <div class="dash__link dash__link--secondary">

                                                                    <a href="#">Ajouter</a></div>
                                                            </div>
                                                        </div>
                                                        <div class="gl-inline">
                                                            <div class="u-s-m-b-30">
                                                                <h2 class="dash__h2 u-s-m-b-8">Photo</h2>

                                                                
                                                                <div class="dash__link dash__link--secondary">
                                                                <input type="file" name="avatar">
                                                                <button name="submit">ttt</button>
                                                                    
                                                                </div>
                                                            </div>
                                                            
                                                        </div>

                                                        <button class="btn btn--e-brand-b-2" name="submit">Enregistrer</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 2 ======-->
        </div>
        <!--====== End - App Content ======-->

        <?php require_once "../elements/footer.php"; ?>

<?php endif ?>