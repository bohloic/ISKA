<?php
session_start();
require "../functions/auth.php";
force_user();
require_once '../elements/header.php';
$email = htmlentities($_SESSION['email']);
$client = $data->query("SELECT * FROM `client` WHERE email = '$email' ");
// var_dump($_SESSION);
?>



        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Section 1 ======-->
            <div class="u-s-p-y-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="breadcrumb">
                            <div class="breadcrumb__wrap">
                                <ul class="breadcrumb__list">
                                    <li class="has-separator">

                                        <a href="index.php">Acceuil</a></li>
                                    <li class="is-marked">

                                        <a href="dash-my-profile.php">Mon compte</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====== End - Section 1 ======-->


            <!--====== Section 2 ======-->
            <div class="u-s-p-b-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="dash">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-3 col-md-12">

                                    <!--====== Dashboard Features ======-->
                                    <?php require_once 'menu-dash.php';?>
                                    <!--====== End - Dashboard Features ======-->
                                </div>
                                <div class="col-lg-9 col-md-12">
                                    <div class="dash__box dash__box--shadow dash__box--radius dash__box--bg-white u-s-m-b-30">
                                        <div class="dash__pad-2">
                                            <h1 class="dash__h1 u-s-m-b-14">Mon profile</h1>

                                            <span class="dash__text u-s-m-b-30">Verifier tous vos informations , vous pourriez personnaliser votre compte.</span>
                                            <div class="row">
                                                <div class="col-lg-4 u-s-m-b-30">
                                                    <h2 class="dash__h2 u-s-m-b-8">Nom complet</h2>

                                                    <span class="dash__text"><?= $client[0]['nom'].' '.$client[0]['prenom'] ?></span>
                                                </div>
                                                <div class="col-lg-4 u-s-m-b-30">
                                                    <h2 class="dash__h2 u-s-m-b-8">E-mail</h2>

                                                    <span class="dash__text"><?= $client[0]['email'] ?></span>
                                                    <div class="dash__link dash__link--secondary">

                                                        <a href="#">Changer</a></div>
                                                </div>
                                                <div class="col-lg-4 u-s-m-b-30">
                                                    <h2 class="dash__h2 u-s-m-b-8">Telephone</h2>

                                                    <span class="dash__text">Entrer le numero de telephone</span>
                                                    <div class="dash__link dash__link--secondary">

                                                        <a href="#">Ajouter</a></div>
                                                </div>
                                                <div class="col-lg-4 u-s-m-b-30">
                                                    <h2 class="dash__h2 u-s-m-b-8">Date de naissance</h2>

                                                    <span class="dash__text"><?= $client[0]['dat_naiss'] ?></span>
                                                </div>
                                                <div class="col-lg-4 u-s-m-b-30">
                                                    <h2 class="dash__h2 u-s-m-b-8">Genre</h2>

                                                    <span class="dash__text"><?= $client[0]['sex'] ?></span>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="dash__link dash__link--secondary u-s-m-b-30">

                                                        <a data-modal="modal" data-modal-id="#dash-newsletter">Souscrivez au journal</a></div>
                                                    <div class="u-s-m-b-16">

                                                        <a class="dash__custom-link btn--e-transparent-brand-b-2" href="dash-edit-profile.php">Edit Profile</a></div>
                                                    <div>

                                                        <a class="dash__custom-link btn--e-brand-b-2" href="#">Changer de mot de passe</a></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 2 ======-->
        </div>
        <!--====== End - App Content ======-->


        <?php require_once '../elements/footer.php'; ?>