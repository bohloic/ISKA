<?php
session_start();
require "../functions/auth.php";
force_user();
require_once '../elements/header.php';
$email = htmlentities($_SESSION['email']);
$client = $data->query("SELECT * FROM `client` WHERE email = '$email' ");
// var_dump($_SESSION);
// unset($_SESSION['connecte']);
// var_dump($client);
// class DBO extends PDO
// {
//     private $driver='mysql';
//     private $host='localhost';
//     private $username='root';
//     private $password='';
//     private $database='iska-africa';
//     private $db;

//     public function __construct($driver, $host ,$username,$password,$database)
//     {   
//         $this->driver=$driver;
//         $this->host=$host;
//         $this->username=$username;
//         $this->password=$password;
//         $this->database=$database;
//         $db = new PDO($this->driver.':host='.$this->host.';port=3309;dbname='.$this->database.';charset=utf8',$this->username,$this->password);
//         $this->db= $db;
//     }
//     public function query(string $query)
//     {
        
//         $requete = $this->db->prepare($query);
//         $requete->execute();
//         $resultat = $requete->fetchAll();  
//     }
    // try{
    //     //driver non trouver mais ça marche; A revoir...
    //     $data = new DB('mysql','localhost', 'root', '','iska-africa');
    //     $sql="SELECT * FROM client WHERE id=?";
    //     // $filepath = realpath (dirname(__FILE__));
    //     if(isset($_POST['submit'])){
    //         $nom=htmlentities(trim($_POST['nom']));
    //         $prenom=htmlentities(trim($_POST['prenom']));
    //         $nomb=htmlentities(trim($_POST['nomb']));
    //         $pays=htmlentities(trim($_POST['pays']));
    //         $mail=htmlentities(trim($_POST['email']));
    //         $tel=htmlentities(trim($_POST['tel'] ));
    //         $identité=htmlentities(trim($_POST['client'] && $_POST['vendeur'] ));
    //         $avatar=$_POST['avatar'];
    //         if(isset($_FLILES['avatar']) AND !empty($_FILES['avatar']['name'])){
    //             $taillevalid=2097152;
    //             $extensioovalid=array('jpg','png','jpeg');
    //             if($_FILES['avatar']['size']<=$taillevalid)
    //             {
    //             $extenssionuplad=strtolower(substr(strrchr($_FILES['avatar']['name'],'.'),start));
    //             if(in_array($extenssionuplad,$extensioovalid))
    //             {
    //                 $chemin="./membre/avatar/".$_SESSION['id'].".".$extenssionuplad;
    //                 $resultat=move_uploaded_file($_FILES['avatar']['tmp_namme'],$chemin);
    //                 if($resultat)
    //                 {
    //                     $updataavatar=$data->prepare("UPDATE client SET avatar=:avatar WHERE id=:id");
    //                     $updataavatar->execute(array(
    //                         'avatar'=>$_SESSION['id'].".".$extenssionuplad,
    //                         'id'=>$_SESSION['id']
    //                     ));
    //                 }else{
    //                     $msg="Erreur durant l'importaton de la photo";
    //                 } 
    //             }else
    //             {
    //                 $msg="Votre photo de profile doit être au format jpg,jpeg,png";
    //             }
    //             }else
    //             {
    //              $msg="votre photo de profile ne doit pas depasser 2 Mo";   
    //             }
    //         }
    //         $mdp=htmlspecialchars(trim($_POST['mdp']));
    //         $confmdp=htmlspecialchars(trim($_POST['confmdp']));
            
            
         
    //     //    if($_POST['mdp']==$_POST['confmdp'])
    //     //    {
                
    //             $sql="INSERT INTO client (nom, prenom, email,nom_boutique,pays,email,identité,tel,password, passConf) VALUES 
    //                                  ('$nom', '$prenom', '$mail',,'$pays','$nomb' '$photo,$tel,$identité, '$mdp')'";
    //             $req=$data->prepare($sql);
    //             $req->execute();
    //             echo "<div class='btn btn-success'>Enregistrement effectué</div>";
    //         // }
    //     }

    // }catch(PDOException $e) {     
    //     die("Error: ".$e->getMessage()); 
    // }

// }


?>




        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Section 1 ======-->
            <div class="u-s-p-y-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="breadcrumb">
                            <div class="breadcrumb__wrap">
                                <ul class="breadcrumb__list">
                                    <li class="has-separator">

                                        <a href="../page/index.php" >Accueil</a></li>
                                    <li class="is-marked">

                                        <a href="dashboard.php">Mon Compte</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====== End - Section 1 ======-->


            <!--====== Section 2 ======-->
            <div class="u-s-p-b-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="dash">
                        <div class="container"><!--====== Dashboard Features ======-->
                                    
                            <div class="row">
                                <div class="col-lg-3 col-md-12">

                                    <?php require_once 'menu-dash.php';?>
                                    <!--====== End - Dashboard Features ======-->
                                </div>
                              
                                <div class="col-lg-9 col-md-12">
                                    <div class="dash__box dash__box--shadow dash__box--radius dash__box--bg-white u-s-m-b-30">
                                        <div class="dash__pad-2">
                                            <span class="dash__text u-s-m-b-30">À partir de votre tableau de bord Mon compte, vous avez la possibilité d'afficher un instantané de l'activité récente de votre compte et de mettre à jour les informations de votre compte. Sélectionnez un lien ci-dessous pour afficher ou modifier les informations.
                                                <div class="row">
                                                    <div class="col-lg-4 u-s-m-b-30">
                                                        <div class="dash__box dash__box--bg-grey dash__box--shadow-2 u-h-100">
                                                            <div class="dash__pad-3">
                                                                <h2 class="dash__h2 u-s-m-b-8">PROFIL PERSONNEL</h2>
                                                                <div class="dash__link dash__link--secondary u-s-m-b-8">

                                                                    <a href="dash-edit-profile.php">Éditer</a></div>

                                                                <span class="dash__h2 u-s-m-b-8">Mr <?=$client[0]['nom'].'&nbsp;'.$client[0]['prenom']?></span>

                                                                <span class="dash__h2 u-s-m-b-8"><strong><?= $client[0]['email']?></strong></span>
                                                                <div class="dash__link dash__link--secondary u-s-m-t-8">

                                                                    <a data-modal="modal" data-modal-id="#dash-newsletter">Abonnez-vous à la newsletter
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 u-s-m-b-30">
                                                        <div class="dash__box dash__box--bg-grey dash__box--shadow-2 u-h-100">
                                                            <div class="dash__pad-3">
                                                                <h2 class="dash__h2 u-s-m-b-8">CARNET D'ADRESSES</h2>

                                                                <span class="dash__text-2 u-s-m-b-8">Adresse de livraison par défaut</span>
                                                                <div class="dash__link dash__link--secondary u-s-m-b-8">

                                                                    <a href="dash-address-book.php">Editer</a></div>

                                                                <span class="dash__text">Abidjan BP 08-Cote d'ivoire</span>

                                                                <span class="dash__text"><strong class="dash__h2 u-s-m-b-8"><?= $client[0]['tel']?></strong></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 u-s-m-b-30">
                                                        <div class="dash__box dash__box--bg-grey dash__box--shadow-2 u-h-100">
                                                            <div class="dash__pad-3">
                                                                <h2 class="dash__h2 u-s-m-b-8">ADRESSE DE FACTURATION</h2>

                                                                <span class="dash__text-2 u-s-m-b-8">adresse de facturation par défaut</span>

                                                                <span class="dash__text">Abidjan BP 08-Cote d'ivoire</span>

                                                                <span class="dash__text"><strong class="dash__h2 u-s-m-b-8"><?= $client[0]['tel']?></strong></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    
                                        <div class="dash__box dash__box--shadow dash__box--bg-white dash__box--radius">
                                            <h2 class="dash__h2 u-s-p-xy-20">DERNIÈRES COMMANDES</h2>
                                            <div class="dash__table-wrap gl-scroll">
                                                <table class="dash__table">
                                                    <thead>
                                                        <tr>
                                                            <th>Commander #</th>
                                                            <th>Placé sur</th>
                                                            <th>Articles</th>
                                                            <th>Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>3054231326</td>
                                                            <td>26/13/2016</td>
                                                            <td>
                                                                <div class="dash__table-img-wrap">

                                                                    <img class="u-img-fluid" src="../images/product/electronic/product3.jpg" alt=""></div>
                                                            </td>
                                                            <td>
                                                                <div class="dash__table-total">

                                                                    <span>$126.00</span>
                                                                    <div class="dash__link dash__link--brand">

                                                                        <a href="dash-manage-order.php">MANAGE</a></div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>3054231326</td>
                                                            <td>26/13/2016</td>
                                                            <td>
                                                                <div class="dash__table-img-wrap">

                                                                    <img class="u-img-fluid" src="../images/product/electronic/product14.jpg" alt=""></div>
                                                            </td>
                                                            <td>
                                                                <div class="dash__table-total">

                                                                    <span>$126.00</span>
                                                                    <div class="dash__link dash__link--brand">

                                                                        <a href="dash-manage-order.php">MANAGE</a></div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>3054231326</td>
                                                            <td>26/13/2016</td>
                                                            <td>
                                                                <div class="dash__table-img-wrap">

                                                                    <img class="u-img-fluid" src="../images/product/men/product8.jpg" alt=""></div>
                                                            </td>
                                                            <td>
                                                                <div class="dash__table-total">

                                                                    <span>$126.00</span>
                                                                    <div class="dash__link dash__link--brand">

                                                                        <a href="dash-manage-order.php">MANAGE</a></div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>3054231326</td>
                                                            <td>26/13/2016</td>
                                                            <td>
                                                                <div class="dash__table-img-wrap">

                                                                    <img class="u-img-fluid" src="../images/product/women/product10.jpg" alt=""></div>
                                                            </td>
                                                            <td>
                                                                <div class="dash__table-total">

                                                                    <span>$126.00</span>
                                                                    <div class="dash__link dash__link--brand">

                                                                        <a href="dash-manage-order.php">MANAGE</a></div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 2 ======-->
        </div>
        <!--====== End - App Content ======-->

        <?php require_once "../elements/footer.php"; ?>