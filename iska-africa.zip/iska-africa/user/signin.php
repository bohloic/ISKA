<?php
session_start();
?>

<?php if(isset($_SESSION['connecte'])) : ?>
   <?php header("Location: http://localhost/iska/user/dashboard.php" );
    exit; ?>
<?php else: ?> 
    <?php
        require_once '../elements/header.php';
        $erreur= null;
        $success = false;
    ?>
        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Section 1 ======-->
            <div class="u-s-p-y-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="breadcrumb">
                            <div class="breadcrumb__wrap">
                                <ul class="breadcrumb__list">
                                    <li class="has-separator">

                                        <a href="index.php">Accueil</a></li>
                                    <li class="is-marked">

                                        <a href="signin.php">Identification</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====== End - Section 1 ======-->


            <!--====== Section 2 ======-->
            <div class="u-s-p-b-60">

                <!--====== Section Intro ======-->
                <div class="section__intro u-s-m-b-60">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="section__text-wrap">
                                    
                                    <?php if($erreur): ?>
                                        <div class="alert alert-danger">
                                            <?= $erreur ?>
                                        </div>
                                    <?php endif ?>
                                    <h1 class="section__heading u-c-secondary">DÉJÀ ENREGISTRÉ?</h1>
                                    
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Intro ======-->


                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="row row--center">
                            <div class="col-lg-6 col-md-8 u-s-m-b-30">
                                <div class="l-f-o">
                                    <div class="l-f-o__pad-box">
                                        <h1 class="gl-h1">JE SUIS NOUVEAU CLIENT</h1>

                                        <span class="gl-text u-s-m-b-30">En créant un compte avec notre boutique, vous pourrez passer plus rapidement à la caisse, stocker les adresses de livraison, afficher et suivre vos commandes dans votre compte et plus encore.</span>
                                        <div class="u-s-m-b-15">

                                            <a class="l-f-o__create-link btn--e-transparent-brand-b-2" href="signup.php">CRÉER UN COMPTE</a>
                                        </div>
                                        <h1 class="gl-h1">S'IDENTIFIER</h1>

                                        <span class="gl-text u-s-m-b-30">Si vous avez un compte chez nous, veuillez vous connecter.</span>
                                        <form action="login.php" method="post">
                                            <div class="gl-s-api">
                                                <div class="u-s-m-b-15">

                                                    <button class="gl-s-api__btn gl-s-api__btn--fb" type="button"><i class="fab fa-facebook-f"></i>

                                                        <span>Se connecter avec Facebook</span>
                                                    </button>
                                                </div>
                                                <div class="u-s-m-b-15">

                                                    <button class="gl-s-api__btn gl-s-api__btn--gplus" type="button"><i class="fab fa-google"></i>

                                                        <span>Se connecter avec Google</span>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="u-s-m-b-30">

                                                <label class="gl-label" for="email">E-MAIL *</label>

                                                <input class="input-text input-text--primary-style <?= isset($_SESSION['error']['email']) ? 'is-invalid' : '' ?>" type="text" name="email" placeholder="Enter E-mail">
                                                <?php if(isset($_SESSION['error']['email'])): ?>
                                                    <div class="invalid-feedback"><?= $_SESSION['error']['email'] ?></div>
                                                <?php endif ?>
                                            </div>
                                            
                                            <div class="u-s-m-b-30">

                                                <label class="gl-label" for="password">MOT DE PASSE *</label>

                                                <input class="input-text input-text--primary-style <?= isset($_SESSION['error']['password']) ? 'is-invalid' : '' ?>" type="password" name="password" placeholder="Enter Password">
                                                <?php if(isset($_SESSION['error']['password'])): ?>
                                                    <div class="invalid-feedback"><?= $_SESSION['error']['password'] ?></div>
                                                <?php endif ?>
                                            </div>
                                            <div class="gl-inline">
                                                <div class="u-s-m-b-30">
                                                <!-- href="dashboard.php" -->
                                                    <button  class="btn btn--e-transparent-brand-b-2" name="submit">CONNEXION</button>
                                                </div>
                                                
                                                <div class="u-s-m-b-30">
                                                    <a class="gl-link" href="lost-password.php">Mot de passe oublié?</a>
                                                </div>
                                            </div>
                                            <div class="u-s-m-b-30">

                                                <!--====== Check Box ======-->
                                                <div class="check-box">

                                                    <input type="checkbox" id="remember-me">
                                                    <div class="check-box__state check-box__state--primary">

                                                        <label class="check-box__label" for="remember-me">Souviens-toi de moi</label></div>
                                                </div>
                                                <!--====== End - Check Box ======-->
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 2 ======-->
        </div>
        <!--====== End - App Content ======-->
        <?php 
            require_once '../elements/footer.php'; 
            if(isset($_SESSION['error'])){
                unset($_SESSION['error']);
            }                                        
        ?>
        
<?php endif ?>
        
        
       


        