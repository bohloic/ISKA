<?php
session_start();
require "../functions/auth.php";
force_user();
require_once '../elements/header.php';
$email = htmlentities($_SESSION['email']);
$client = $data->query("SELECT * FROM `client` WHERE email = '$email' ");
?>



        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Section 1 ======-->
            <div class="u-s-p-y-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="breadcrumb">
                            <div class="breadcrumb__wrap">
                                <ul class="breadcrumb__list">
                                    <li class="has-separator">

                                        <a href="index.php">Acceuil</a></li>
                                    <li class="is-marked">

                                        <a href="dash-address-book.php">MON COMPTE</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====== End - Section 1 ======-->


            <!--====== Section 2 ======-->
            <div class="u-s-p-b-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="dash">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-3 col-md-12">

                                    <!--====== Dashboard Features ======-->
                                    <?php require_once 'menu-dash.php';?>
                                    <!--====== End - Dashboard Features ======-->
                                </div>
                                <div class="col-lg-9 col-md-12">
                                    <div class="dash__box dash__box--shadow dash__box--radius dash__box--bg-white u-s-m-b-30">
                                        <div class="dash__pad-2">
                                            <div class="dash__address-header">
                                                <h1 class="dash__h1">Addresse de reservation</h1>
                                                <div>

                                                    <span class="dash__link dash__link--black u-s-m-r-8">

                                                        <a href="dash-address-make-default.php">Faire une adresse de livraison par défaut</a></span>

                                                    <span class="dash__link dash__link--black">

                                                        <a href="dash-address-make-default.php">Faire une adresse de livraison par défaut</a></span></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="dash__box dash__box--shadow dash__box--bg-white dash__box--radius u-s-m-b-30">
                                        <div class="dash__table-2-wrap gl-scroll">
                                            <table class="dash__table-2">
                                                <thead>
                                                    <tr>
                                                        <th>Action</th>
                                                        <th>Nom</th>
                                                        <th>Addresse</th>
                                                        <th>Region</th>
                                                        <th>Numero telephone</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>

                                                            <a class="address-book-edit btn--e-transparent-platinum-b-2" href="dash-address-edit.php">Edit</a></td>
                                                        <td>John Doe</td>
                                                        <td>Abidjan BP 08-CI</td>
                                                        <td>Abidjan BP 08-CI</td>
                                                        <td>0787785170</td>
                                                        <td>
                                                            <div class="gl-text">Default Shipping Address</div>
                                                            <div class="gl-text">Default Billing Address</div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>

                                                            <a class="address-book-edit btn--e-transparent-platinum-b-2" href="dash-address-edit.php">Edit</a></td>
                                                        <td>Doe John</td>
                                                        <td>Abidjan BP 08-CI</td>
                                                        <td>Abidjan BP 08-CI</td>
                                                        <td>(+0) 7154419563</td>
                                                        <td></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div>

                                        <a class="dash__custom-link btn--e-brand-b-2" href="dash-address-add.php"><i class="fas fa-plus u-s-m-r-8"></i>

                                            <span>Ajouter nouvelle adresse</span></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 2 ======-->
        </div>
        <!--====== End - App Content ======-->


        <?php require_once "../elements/footer.php"; ?>