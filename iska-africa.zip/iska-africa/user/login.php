<?php
session_start();
if(isset($_POST['submit'])){
    $email = htmlentities($_POST['email']);
    $pass = htmlentities($_POST['password']);

    $db = new PDO('mysql:host=localhost;dbname=iska-africa;port=3309', 'root', '');
    $sql= "SELECT * FROM client WHERE email = '$email' ";
    $result = $db->prepare($sql);
    $result->execute(); 

    if($result->rowCount() > 0){
        
        $data = $result->fetchAll(); 
        $id= $data[0]['id'];
        if(password_verify($pass , $data[0]['password'])){
            echo "Connexion effectuée";
            $_SESSION['connecte']= 1;
            $_SESSION['email'] = $email;
            if(isset($_SESSION['commande'])){                
                header('Location: http://localhost/iska/user/dash-my-order.php');
            }else{
                header("Location: http://localhost/iska/user/dashboard.php");
                exit;
            }
        }else{
            $_SESSION['email'] = $email;
            $_SESSION['error']['password']='Mot de passe incorrect';
            header("Location: http://localhost/iska/user/signin.php");
            exit;
        }
    }else{
        $_SESSION['error']['email']='Email incorrect';
        header("Location: http://localhost/iska/user/signin.php");
        exit;
    }

}
// header("Location: http://localhost/iska/user/dashboard.php", true, );
// exit;
?>
