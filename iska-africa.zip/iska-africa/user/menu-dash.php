<div class="dash__box dash__box--bg-white dash__box--shadow u-s-m-b-30">
    <div class="dash__pad-1">
        <div class="mb-2">

            <span class=""><h3> Mr <?=$client[0]['nom'] ?></h3></span>
                                
            <!-- <img src="<?=$client[0]['avatar'] ?>" style="height: 150; width: 150px;"> -->
        </div>    
        <ul class="dash__f-list">

        <?= dash_menu('dash')?>
            <!-- <li>

                <a class="dash-active" href="dashboard.php">Gérer mon compte</a></li>
            <li>

                <a href="dash-my-profile.php">Mon profil</a></li>
            <li>

                <a href="dash-address-book.php">Carnet d'adresses</a></li>
            <li>

                <a href="dash-track-order.php">Suivi de commande</a></li>
            <li>

                <a href="dash-my-order.php">Mes commandes</a></li>
            <li>

                <a href="dash-payment-option.php">Mes options de paiement</a></li>
            <li>

                <a href="dash-cancellation.php">Mes retours et annulations</a></li>
            
            <li>

                <a href="logout.php">Déconnexion</a></li> -->
        </ul>
    </div>
</div>
<div class="dash__box dash__box--bg-white dash__box--shadow dash__box--w">
    <div class="dash__pad-1">
        <ul class="dash__w-list">
            <li>
                <div class="dash__w-wrap">

                    <span class="dash__w-icon dash__w-icon-style-1"><i class="fas fa-cart-arrow-down"></i></span>

                    <span class="dash__w-text">4</span>

                    <span class="dash__w-name">Commandes placé</span></div>
            </li>
            <li>
                <div class="dash__w-wrap">

                    <span class="dash__w-icon dash__w-icon-style-2"><i class="fas fa-times"></i></span>

                    <span class="dash__w-text">0</span>

                    <span class="dash__w-name">Annulation de commande</span></div>
            </li>
            <li>
                <div class="dash__w-wrap">

                    <span class="dash__w-icon dash__w-icon-style-3"><i class="far fa-heart"></i></span>

                    <span class="dash__w-text">0</span>

                    <span class="dash__w-name">Liste de souhaits</span></div>
            </li>
        </ul>
    </div>
</div>