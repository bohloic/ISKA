<?php
session_start();
?>

    <?php 
        require_once '../elements/header.php';
        $errors= null;
        $success = false;
        var_dump($_POST);
        if(isset($_POST['nom'], $_POST['prenom'], $_POST['email'], $_POST['nomb'], $_POST['typeclt'], $_POST['mdp'],$_POST['re_mdp'])){
            $inscription = new Client($data, $_POST['nom'], $_POST['prenom'], $_POST['email'], $_POST['nomb'], $_POST['typeclt'], $_POST['mdp'],$_POST['re_mdp']);
            if($inscription->isValid()){
                $save = $inscription->inscription($_POST['nom'], $_POST['prenom'], $_POST['email'], $_POST['nomb'], $_POST['typeclt'], $_POST['mdp']);
                $_SESSION['inscris']=true; 
                $_SESSION['est-inscris'] = true;
                $nom = strtoupper(htmlentities($_POST['nom']));
                $_POST = [];

            }else{
                $errors = $inscription->getErrors();                
            }
            
        }
    ?>


            <!--====== App Content ======-->
            <div class="app-content">

                <!--====== Section 1 ======-->
                <div class="u-s-p-y-60">

                    <!--====== Section Content ======-->
                    <div class="section__content">
                        <div class="container">
                            <div class="breadcrumb">
                                <div class="breadcrumb__wrap">
                                    <ul class="breadcrumb__list">
                                        <li class="has-separator">

                                            <a href="../page/index.php">Acceuil</a></li>
                                        <li class="is-marked">

                                            <a href="signup.php">Connexion</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section 1 ======-->

                
                <!--====== Section 2 ======-->
                <div class="u-s-p-b-60">

                    <!--====== Section Intro ======-->
                    <div class="section__intro u-s-m-b-60">
                        <div class="container">
                            
                            <div class="row">
                                <div class="col-lg-12">
                                    <!--  -->
                                    
                                    <div class="section__text-wrap">
                                    
                                        <h1 class="section__heading u-c-secondary">CREER UN COMPTE</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--====== End - Section Intro ======-->
        
                    

                    <!--====== Section Content ======-->
                    <div class="section__content">
                        <div class="container">
                        <?php if(!empty($errors)): ?>
                                <div class="row row--center">
                                    <div class="col-lg-6 col-md-8 u-s-m-b-30">                                
                                        <div class="alert alert-danger">
                                            Formulaire invalide 
                                        </div>                                
                                    </div>
                                </div>
                            <?php endif ?>
                            <?php if(isset($_SESSION['inscris'])): ?>
                                <div class="alert alert-success">
                                    Félicitation M. <?= $nom ?>, votre inscription a été effectué. Cliquez <a href="signin.php">ici</a> pour vous connecter.
                                </div>
                            
                            <?php endif ?>
                            <div class="row row--center">
                                <div class="col-lg-6 col-md-8 u-s-m-b-30">
                                    <div class="l-f-o">
                                        <div class="l-f-o__pad-box">
                                            <h1 class="gl-h1">INFORMATION PERSONNEL</h1>
                                            <form action="" class="l-f-o__form" method="post" >
                                                
                                                <div class="gl-s-api">
                                                    <div class="u-s-m-b-15">

                                                        <button class="gl-s-api__btn gl-s-api__btn--fb" type="button"><i class="fab fa-facebook-f"></i>

                                                            <span>Se connecter avec facebook</span></button></div>
                                                    <div class="u-s-m-b-30">

                                                        <button class="gl-s-api__btn gl-s-api__btn--gplus" type="button"><i class="fab fa-google"></i>

                                                            <span>Se connecter avec Google</span></button></div>
                                                </div>
                                                <div class="u-s-m-b-30">

                                                    <label class="gl-label" >Nom *</label>

                                                    <input class="input-text input-text--primary-style <?= isset($errors['nom']) ? 'is-invalid' : '' ?>" type="text" name="nom" value="<?= $_POST['nom'] ?? '' ?>">
                                                    <?php if(isset($errors['nom'])): ?>
                                                        <div class="invalid-feedback"><?= $errors['nom'] ?></div>
                                                    <?php endif ?>
                                                </div>
                                                <div class="u-s-m-b-30">

                                                    <label class="gl-label" >Prenom *</label>

                                                    <input class="input-text input-text--primary-style <?= isset($errors['prenom']) ? 'is-invalid' : '' ?>" type="text"  name="prenom" value="<?= $_POST['prenom'] ?? '' ?>">
                                                    <?php if(isset($errors['prenom'])): ?>
                                                        <div class="invalid-feedback"><?= $errors['prenom'] ?></div>
                                                    <?php endif ?>
                                                </div>                                               
                                                <div class="u-s-m-b-30">

                                                    <label class="gl-label" >Email *</label>

                                                    <input class="input-text input-text--primary-style <?= isset($errors['email']) ? 'is-invalid' : '' ?>" type="text"  name="email" value="<?= $_POST['email'] ?? '' ?>">
                                                    <?php if(isset($errors['email'])): ?>
                                                        <div class="invalid-feedback"><?= $errors['email'] ?></div>
                                                    <?php endif ?>
                                                </div>
                                                <div class="u-s-m-b-30">

                                                    <label class="gl-label" >Nom de la boutique *</label>

                                                    <input class="input-text input-text--primary-style <?= isset($errors['nomb']) ? 'is-invalid' : '' ?>" type="text"  name="nomb" value="<?= $_POST['nomb'] ?? '' ?>">
                                                    <?php if(isset($errors['nomb'])): ?>
                                                        <div class="invalid-feedback"><?= $errors['nomb'] ?></div>
                                                    <?php endif ?>
                                                </div>
                                                <div class="u-s-m-b-30">

                                                    <label class="gl-label" >Je suis *</label>
                                                    <select name="typeclt" class="input-text input-text--primary-style <?= isset($errors['typeclt']) ? 'is-invalid' : '' ?>" >
                                                        <option  value="0"> choix</option>
                                                        <option  value="Acheteur"> Acheteur</option>
                                                        <option  value="Vendeur"> Vendeur</option>
                                                        <option  value="Admin"> Admin</option>
                                                        <option  value="Super Admin"> Super Admin</option>
                                                    </select>
                                                    <?php if(isset($errors['typeclt'])): ?>
                                                        <div class="invalid-feedback"><?= $errors['typeclt'] ?></div>
                                                    <?php endif ?>
                                                </div>
                                                <div class="u-s-m-b-30">

                                                    <label class="gl-label" >Mot de passe *</label>

                                                    <input class="input-text input-text--primary-style <?= isset($errors['mdp']) ? 'is-invalid' : '' ?>" type="password" name="mdp" value="<?= $_POST['mdp'] ?? '' ?>">
                                                    <?php if(isset($errors['mdp'])): ?>
                                                        <div class="invalid-feedback"><?= $errors['mdp'] ?></div>
                                                    <?php endif ?>
                                                </div>
                                                <div class="u-s-m-b-30">

                                                    <label class="gl-label" >Confirmé mot de passe *</label>

                                                    <input class="input-text input-text--primary-style <?= isset($errors['re_mdp']) ? 'is-invalid' : '' ?>" type="password" name="re_mdp" value="<?= $_POST['re_mdp'] ?? '' ?>">
                                                    <?php if(isset($errors['re_mdp'])): ?>
                                                        <div class="invalid-feedback"><?= $errors['re_mdp'] ?></div>
                                                    <?php endif ?>
                                                </div>
                                                <div class="u-s-m-b-15">                                                
                                                        <button class="btn btn--e-transparent-brand-b-2" type="submit" name="submit"> CREER</button>
                                                </div>
                                                <a class="gl-link" href="#">Retourner pour stocker</a>
                                            </form>                                                                                   
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--====== End - Section Content ======-->
                </div>
                <!--====== End - Section 2 ======-->
            </div>
            <!--====== End - App Content ======-->


            <?php 
                require_once '../elements/footer.php'; 
                if(isset($_SESSION['inscris'])) {
                    unset($_SESSION['inscris']); 
                }    

            ?>
