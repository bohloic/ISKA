<?php
require "../include/fonction.php";
require "../config/database.php";
require "../include/constant.php";
//si le formulaire à été soumis
if(isset($_POST['submit'])){
//si tous les champs ont été remplis
    // if(!empty($_POST['nom']) && !empty($_POST['prenom']) &&!empty($_POST['nomb']) && !empty($_POST['pays'])
    // && !empty($_POST['email']) && !empty($_POST['mdp']) && !empty($_POST['confmdp']) && !empty($_POST['tel']) && !empty($_POST['client'])
    // && !empty($_POST['vendeur'])){
        if(not_empty(['nom','prenom','nomb','pays','email','mdp','confmdp','tel','client','vendeur'])){

        $error=[''];
        extract($_POST);
        if(mb_strlen($nom<3)){
            $error[]="Nom trop court(Minimum 3 caractères)";
        }
        if(!filter_var($mail,FILTER_VALIDATE_EMAIL)){
            $error[]="Adresse email invalid";
        }
        if(mb_strlen($password<6)){
            $error[]="Mot de passe trop court(Minimum 6 caractères)";
        }else
        {
            if($password!=$confmdp){
                $error[]="Les deus mots de passe ne concordent pas";
            }
        }
        if(is_already_in_use('nom',$nom,'client')){
            $error[]="Nom déjas utilisé";
        }
        if(is_already_in_use('email',$mail,'client')){
            $error[]="Email déjas utilisé";
        }
        // if(isset($_FLILES['avatar']) AND !empty($_FILES['avatar']['name'])){
        //     $taillevalid=2097152;
        //     $extensioovalid=array('jpg','png','jpeg');
        //     if($_FILES['avatar']['size']<=$taillevalid)
        //     {
        //     $extenssionuplad=strtolower(substr(strrchr($_FILES['avatar']['name'],'.'),start()));
        //     if(in_array($extenssionuplad,$extensioovalid))
        //     {
        //         $chemin="./membre/avatar/".$_SESSION['id'].".".$extenssionuplad;
        //         $fichier=basename($_FILES['avatar']['name']);
        //         $resultat=move_uploaded_file($_FILES['avatar']['tmp_namme'],$chemin,$fichier);
        //         if($resultat)
        //         {
        //             echo"fichier envoyé avec succès";
        //             $updataavatar=$data->prepare("UPDATE client SET avatar=:avatar WHERE id=:id");
        //             $updataavatar->execute(array(
        //                 'avatar'=>$_SESSION['id'].".".$extenssionuplad,
        //                 'id'=>$_SESSION['id']
        //             ));
        //         }else{
        //             $msg="Erreur durant l'importaton de la photo";
        //         } 
        //     }else
        //     {
        //         $msg="Votre photo de profile doit être au format jpg,jpeg,png";
        //     }
        //     }else
        //     {
        //      $msg="votre photo de profile ne doit pas depasser 2 Mo";   
        //     }
        }
        if(is_countable($error)==0){
            //Enregistrement de l'utilisateur
            $to=$_POST['email'];
            $subject=WEBSITE_NAME."-ACTIVATION DE COMPTE";
            $token=sha1($_POST['nom'].$_POST['email'].$_POST['mdp']);

            ob_start();
            require "../template/email/activation.php";
            $content=ob_get_clean();

            $header='MIME-Version:1.0'."\r\n";
            $header='Mcontent-type:text/html;charset=iso-8859-1'."\r\n";

            mail($to,$subject,$content,$header);

            //Messagede bienvenue
            echo "mail d'activation envoyé";
            //Redirection vers la page de profil
        }
    }
    else
    {
        $error[]="Veuillez rempli tous les champs!";
    }
// }

?>
<?php require "signin.php"; ?>