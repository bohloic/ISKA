<?php
session_start();
require "../functions/auth.php";
force_user();
require_once '../elements/header.php';
$email = htmlentities($_SESSION['email']);
$client = $data->query("SELECT * FROM `client` WHERE email = '$email' ");
$id_Client= (int)$client[0]['id'];
$total = $panier->total();
// var_dump($id_Client);
$commande = new Command($data,$id_Client);
if(isset($_SESSION['commande'])){
    unset($_SESSION['commande']);
    $commande->newCommande($_SESSION['panier']);   
    unset($_SESSION['panier']); 
} 
$display= $data->query("SELECT bon_commande.id as idBcde, bon_commande.statut as statut, 
        bon_commande.date as date, bon_commande.heure as heure FROM bon_commande, client 
        WHERE client.id = bon_commande.client and client.id = $id_Client");
// var_dump($display);

?>



        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Section 1 ======-->
            <div class="u-s-p-y-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="breadcrumb">
                            <div class="breadcrumb__wrap">
                                <ul class="breadcrumb__list">
                                    <li class="has-separator">

                                        <a href="index.php">Acceuil</a></li>
                                    <li class="is-marked">

                                        <a href="dash-my-order.php">Mon compte</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====== End - Section 1 ======-->


            <!--====== Section 2 ======-->
            <div class="u-s-p-b-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="dash">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-3 col-md-12">

                                    <!--====== Dashboard Features ======-->
                                    <?php require_once 'menu-dash.php';?>
                                    <!--====== End - Dashboard Features ======-->
                                </div>
                                <div class="col-lg-9 col-md-12">
                                    <div class="dash__box dash__box--shadow dash__box--radius dash__box--bg-white u-s-m-b-30">
                                        <div class="dash__pad-2">
                                            <h1 class="dash__h1 u-s-m-b-14">Mes commandes</h1>

                                            <span class="dash__text u-s-m-b-30">Ici vous pouvez voir tous les produits qui vous ont été livré.</span>
                                            <form class="m-order u-s-m-b-30">
                                                <div class="m-order__select-wrapper">

                                                    <label class="u-s-m-r-8" for="my-order-sort">Montrer:</label>
                                                    <select class="select-box select-box--primary-style" id="my-order-sort">
                                                        <option selected>Les 5 derniers commandess</option>
                                                        <option>Les 15 derniers jours</option>
                                                        <option>Les 30 derniers jours</option>
                                                        <option>Les 6 derniers mois</option>
                                                        <option>Commandes placé en 2018</option>
                                                        <option>Tous les commandes</option>
                                                    </select>
                                                </div>
                                            </form>
                                            <div class="m-order__list">
                                                <?php foreach($display as $value): ?>
                                                    <?php $products = $data->query("SELECT commander.bon_commande as idBcde, commander.quantite AS qte , 
                                                    product.image as image , product.name as nom FROM `commander` ,product 
                                                    WHERE commander.product = product.id  and commander.bon_commande = ".$value['idBcde']." "); ?>

                                                    
                                                    
                                                    <div class="m-order__get">
                                                        <div class="manage-o__header u-s-m-b-30">
                                                            <div class="dash-l-r">
                                                                <div>
                                                                    <div class="manage-o__text-2 u-c-secondary">Order #<?= $value['idBcde']?></div>
                                                                    <div class="manage-o__text u-c-silver">Placé le <?= $value['date'] ?> à <?= $value['heure'] ?></div>
                                                                </div>
                                                                <div>
                                                                    <div class="dash__link dash__link-- brand">

                                                                        <a href="dash-manage-order.php">GERER</a></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="manage-o__description" >
                                                            <div class="row" style="width:100%;">
                                                            
                                                                <div class="col-md-6">
                                                                    <?php foreach($products as $product) : ?>
                                                                        <div class="description__container mt-2">
                                                                            <div class="description__img-wrap" >

                                                                                <img class="u-img-fluid" src="../<?= $product['image'] ?>" alt="<?= $product['nom'] ?>">
                                                                            </div>
                                                                            <div class="description-title" >
                                                                                <?= $product['nom'] ?> <br>
                                                                            
                                                                                <span class="manage-o__text-2 u-c-silver">Quantity:
                                                                                    <span class="manage-o__text-2 u-c-secondary"><?= $product['qte'] ?></span>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    <?php endforeach ?>
                                                                </div>
                                                                
                                                                <div class="col-md-6" style="text-align:right">
                                                                    <div class="description__info-wrap">                                                                
                                                                        <div>
                                                                            <span class="manage-o__badge badge--processing"><?= $value['statut'] ?></span>
                                                                        </div>                                                                    

                                                                        <span class="manage-o__text-2 u-c-silver">Total:

                                                                            <span class="manage-o__text-2 u-c-secondary"><?= $commande->total($value['idBcde']) ?> F</span>
                                                                        </span>
                                                                    </div>                                                                
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach ?>
                                                <!-- <div class="m-order__get">
                                                    <div class="manage-o__header u-s-m-b-30">
                                                        <div class="dash-l-r">
                                                            <div>
                                                                <div class="manage-o__text-2 u-c-secondary">Order #305423126</div>
                                                                <div class="manage-o__text u-c-silver">Placé le 26 Oct 2016 09:08:37</div>
                                                            </div>
                                                            <div>
                                                                <div class="dash__link dash__link--brand">

                                                                    <a href="dash-manage-order.php">GERER</a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="manage-o__description">
                                                        <div class="description__container">
                                                            <div class="description__img-wrap">

                                                                <img class="u-img-fluid" src="images/product/women/product8.jpg" alt=""></div>
                                                            <div class="description-title">New Dress D Nice Elegant</div>
                                                        </div>
                                                        <div class="description__info-wrap">
                                                            <div>

                                                                <span class="manage-o__badge badge--shipped">Expédié</span></div>
                                                            <div>

                                                                <span class="manage-o__text-2 u-c-silver">Quantité:

                                                                    <span class="manage-o__text-2 u-c-secondary">1</span></span></div>
                                                            <div>

                                                                <span class="manage-o__text-2 u-c-silver">Total:

                                                                    <span class="manage-o__text-2 u-c-secondary">$16.00</span></span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="m-order__get">
                                                    <div class="manage-o__header u-s-m-b-30">
                                                        <div class="dash-l-r">
                                                            <div>
                                                                <div class="manage-o__text-2 u-c-secondary">Order #305423126</div>
                                                                <div class="manage-o__text u-c-silver">Placé le 26 Oct 2016 09:08:37</div>
                                                            </div>
                                                            <div>
                                                                <div class="dash__link dash__link--brand">

                                                                    <a href="dash-manage-order.php">GERER</a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="manage-o__description">
                                                        <div class="description__container">
                                                            <div class="description__img-wrap">

                                                                <img class="u-img-fluid" src="images/product/men/product8.jpg" alt=""></div>
                                                            <div class="description-title">New Fashion D Nice Elegant</div>
                                                        </div>
                                                        <div class="description__info-wrap">
                                                            <div>

                                                                <span class="manage-o__badge badge--delivered">Livré</span></div>
                                                            <div>

                                                                <span class="manage-o__text-2 u-c-silver">Quantité:

                                                                    <span class="manage-o__text-2 u-c-secondary">1</span></span></div>
                                                            <div>

                                                                <span class="manage-o__text-2 u-c-silver">Total:

                                                                    <span class="manage-o__text-2 u-c-secondary">$16.00</span></span></div>
                                                        </div>
                                                    </div>
                                                </div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 2 ======-->
        </div>
        <!--====== End - App Content ======-->


        <?php require_once "../elements/footer.php"; ?>