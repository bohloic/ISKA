<?php
session_start();
if(isset($_POST['submit'])){
    if(isset($_POST['nom'],$_POST['prenom'])){
        if(strlen($_POST['nom'])>3 && strlen($_POST['prenom'])>5){
            echo "yes";
            $nom = htmlentities($_POST['nom']);
            $prenom = htmlentities($_POST['prenom']);
            if(isset($_POST['sex'])){
                $sex = htmlentities($_POST['sex']);
                $update = $data->query("UPDATE `client` SET`sex`='$sex' WHERE email ='$email'");

            }
            if(isset($_POST['j'],$_POST['m'],$_POST['y'])){
                $birth = htmlentities($_POST['y']).'-'.htmlentities($_POST['m']).'-'.htmlentities($_POST['j']);   
                $update = $data->query("UPDATE `client` SET `dat_naiss`='$birth' WHERE email ='$email'");         
            }
            $update = $data->query("UPDATE `client` SET `nom`='$nom',`prenom`='$prenom' WHERE email ='$email'");
            $_SESSION['user']['profil']=true;
            // $_SESSION
            // var_dump($_SESSION);
        }else{
            if(strlen($_POST['nom'])<3){
                $errors['nom'] = "le nom est trop court";             
            }

            if(strlen($_POST['prenom'])<3){
                $errors['prenom'] = "le prenom est trop court";             
            }
        }
        // echo "yes";
    }
}