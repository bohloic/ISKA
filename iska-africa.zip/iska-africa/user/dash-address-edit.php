<?php
session_start();
require "../functions/auth.php";
force_user();
require_once '../elements/header.php';
$email = htmlentities($_SESSION['email']);
$client = $data->query("SELECT * FROM `client` WHERE email = '$email' ");
?>



        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Section 1 ======-->
            <div class="u-s-p-y-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="breadcrumb">
                            <div class="breadcrumb__wrap">
                                <ul class="breadcrumb__list">
                                    <li class="has-separator">

                                        <a href="index.php">Acceuil</a></li>
                                    <li class="is-marked">

                                        <a href="dash-address-edit.php">Mon compte</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====== End - Section 1 ======-->


            <!--====== Section 2 ======-->
            <div class="u-s-p-b-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="dash">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-3 col-md-12">

                                    <!--====== Dashboard Features ======-->
                                    <?php require_once 'menu-dash.php';?>
                                    <!--====== End - Dashboard Features ======-->
                                </div>
                                <div class="col-lg-9 col-md-12">
                                    <div class="dash__box dash__box--shadow dash__box--radius dash__box--bg-white">
                                        <div class="dash__pad-2">
                                            <h1 class="dash__h1 u-s-m-b-14">Editer Addresse</h1>

                                            <span class="dash__text u-s-m-b-30">Nous avons des addresse ou nous pouvons vous livrer nos produits.</span>
                                            <form class="dash-address-manipulation">
                                                <div class="gl-inline">
                                                    <div class="u-s-m-b-30">

                                                        <label class="gl-label" for="address-fname">Nom*</label>

                                                        <input class="input-text input-text--primary-style" type="text" id="address-fname" placeholder="John Doe"></div>
                                                    <div class="u-s-m-b-30">

                                                        <label class="gl-label" for="address-lname">Prenom *</label>

                                                        <input class="input-text input-text--primary-style" type="text" id="address-lname" placeholder="Doe"></div>
                                                </div>
                                                <div class="gl-inline">
                                                    <div class="u-s-m-b-30">

                                                        <label class="gl-label" for="address-phone">Telephone *</label>

                                                        <input class="input-text input-text--primary-style" type="text" id="address-phone" placeholder="(+0) 900901904"></div>
                                                    <div class="u-s-m-b-30">

                                                        <label class="gl-label" for="address-street">Addresse de rue*</label>

                                                        <input class="input-text input-text--primary-style" type="text" id="address-street" placeholder="4247 Ashford Drive Virginia"></div>
                                                </div>
                                                <div class="gl-inline">
                                                    <div class="u-s-m-b-30">

                                                        <!--====== Select Box ======-->

                                                        <label class="gl-label" for="address-country">Pays *</label><select class="select-box select-box--primary-style" id="address-country">
                                                            <option selected value="">Choisir un pays</option>
                                                            <option value="uae">United Arab Emirate (UAE)</option>
                                                            <option value="uk">United Kingdom (UK)</option>
                                                            <option value="us">United States (US)</option>
                                                        </select>
                                                        <!--====== End - Select Box ======-->
                                                    </div>
                                                    <div class="u-s-m-b-30">

                                                        <!--====== Select Box ======-->

                                                        <label class="gl-label" for="address-state">Etat/Region *</label><select class="select-box select-box--primary-style" id="address-state">
                                                            <option selected value="">Choisir Etat/Region</option>
                                                            <option value="al">Alabama</option>
                                                            <option value="al">Alaska</option>
                                                            <option value="ny">New York</option>
                                                        </select>
                                                        <!--====== End - Select Box ======-->
                                                    </div>
                                                </div>
                                                <div class="gl-inline">
                                                    <div class="u-s-m-b-30">

                                                        <label class="gl-label" for="address-city">ville/Quartier *</label>

                                                        <input class="input-text input-text--primary-style" type="text" id="address-city"></div>
                                                    <div class="u-s-m-b-30">

                                                        <label class="gl-label" for="address-street">ZIP/CODE POSTAL *</label>

                                                        <input class="input-text input-text--primary-style" type="text" id="address-postal" placeholder="20006"></div>
                                                </div>

                                                <button class="btn btn--e-brand-b-2" type="submit">ENREGISTRER</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 2 ======-->
        </div>
        <!--====== End - App Content ======-->


        <?php require_once "../elements/footer.php"; ?>