<?php
$title= "Deconnection";
if($title==='Deconnection'){
    session_start();
    unset($_SESSION['connecte']);
    unset($_SESSION['email']);
    header('Location: http://localhost/iska/user/signin.php');
}