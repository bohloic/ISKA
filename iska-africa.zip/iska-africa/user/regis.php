<?php
require "../DB.php";
require "../config/config.php";

try{
    //driver non trouver mais ça marche; A revoir...
    $data = new DB('mysql','localhost', 'root', '','iska-africa');
    if($data){
        echo"je te connais";
    }else{
        echo "Je ne te connais pas";
    }
    // S'il y a une session alors on ne retourne plus sur cette page
if (isset($_SESSION["id"])){
header("Location: signin.php");
   exit;
}
    //     // Si la variable "$_Post" contient des informations alors on les traitres
    
if(!empty($_POST)){ 
extract($_POST);
$valid = true;
     
    //         // On se place sur le bon formulaire grâce au "name" de la balise "input"
if (isset($_POST["inscription"])){
$nom  = $_POST['nom'] ;// On récupère le nom
$prenom = $_POST['prenom'];
$nomb  = $_POST['nomb'];// on récupère le prénom
$phto = $_POST['photo'];
$pays = $_POST['pays'];
$mail =$_POST['email']; // On récupère le mail
$mdp = $_POST['mdp'] ;// On récupère le mot de passe 
$confmdp = trim($confmdp); //  On récupère la confirmation du mot de passe
     
    //            // //  Vérification du nom
if(empty($nom)){
$valid = false;
$er_nom = ("Le nom d'\' utilisateur ne peut pas être vide");
// }       
     
    //             //  Vérification du prénom
if(empty($prenom)){
$valid = false;
$er_prenom = ("Le prenom d'\' utilisateur ne peut pas être vide");
}
if(empty($nomb)){
    $valid = false;
    $er_nomb = ("Le nom de la boutique de l'\' utilisateur ne peut pas être vide");
    }
if(empty($photo)){
    $valid = false;
    $er_photo = ("La photo d'\' utilisateur ne peut pas être vide");
    }
    if(empty($pays)){
        $valid = false;
        $er_pays = ("Le nom du pays de l'\' utilisateur ne peut pas être vide");
        }
     
    //             // Vérification du mail
if(empty($mail)){
$valid = false;
$er_mail = "Le mail ne peut pas être vide";
     
    //                 // On vérifit que le mail est dans le bon format
}elseif(!preg_match("/^[a-z0-9\-_.]+@[a-z]+\.[a-z]{2,3}$/i", $mail)){
$valid = false;
$er_mail = "Le mail n'est pas valide";
     
}else{
    //                 // On vérifit que le mail est disponible
$req_mail = $DB->query("SELECT email FROM client WHERE email = ?",
array($mail));
     
$req_mail = $req_mail->fetch();
     
if ($req_mail['mail'] <> ""){
$valid = false;
$er_mail = "Ce mail existe déjà";
}
}
     
    //             // Vérification du mot de passe
if(empty($mdp)) {
$valid = false;
$er_mdp = "Le mot de passe ne peut pas être vide";
     
}elseif($mdp != $confmdp){
$valid = false;
$er_mdp = "La confirmation du mot de passe ne correspond pas";
}
     
    //             // Si toutes les conditions sont remplies alors on fait le traitement
if($valid){
$mdp = crypt($mdp, "$6$rounds=5000$macleapersonnaliseretagardersecret$");
$date_creation_compte = date('Y-m-d H:i:s');
     
    //                 // On insert nos données dans la table utilisateur
$DB->insert("INSERT INTO client (firstname, lastname, email,Boutique_name,pays, password, photo) VALUES 
                        (?, ?, ?, ?, ?)", array($nom, $prenom, $mail,$nomb ,$pays, $mdp, $photo));
     
header('Location: dashboard.php');
exit;
}
}
}

}}
catch(PDOException $e)
{     
    die("Error: ".$e->getMessage()); 
}


?>


?>