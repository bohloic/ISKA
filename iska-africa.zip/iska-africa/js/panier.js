(function ($){
    $('.addPanier').click(function(event){
        event.preventDefault();
        $.get($(this).attr('href'),{},function(data){
            if(data.error){
                alert(data.message);
            }else{
                $('#total').empty().append(data.total);
                $('#count').empty().append(data.count);                 
                $('#countL').empty().append(data.countL); 
            }
        }, 'json');
        return false;
    });
})(jQuery);