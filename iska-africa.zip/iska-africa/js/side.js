(function (){
    
    
        var scrollY = function (){
            var supportPageOffset = window.pageXOffset !== undefined;
            var isCSS1Compat = ((document.compatMode || "") === "CSS1Compat");
            return supportPageOffset ? window.pageYOffset : isCSS1Compat ? document.documentElement.scrollTop : document.body.scrollTop;
        }
    var box = document.querySelector('.ptiAnime').getBoundingClientRect()
    var elements = document.querySelector('[data-slide]')
    for (var i = 0 ; i< elements.length; i++){
        (function(element){
            if(i===0){
                var slideAnime = function (){
                    if(box.top === box.height){
                        element.classList.add('.left')
                    }
                }
            }else{
                var slideAnime = function (){
                    if(box.top === box.height){
                        element.classList.add('.right')
                    }
                }
            }
            element.addEventListener('animationstart', slideAnime())
        })(elements[i])
    }
})()



