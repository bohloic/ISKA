-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3309
-- Généré le :  sam. 01 jan. 2022 à 00:03
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `iska-africa`
--

-- --------------------------------------------------------

--
-- Structure de la table `bon_commande`
--

DROP TABLE IF EXISTS `bon_commande`;
CREATE TABLE IF NOT EXISTS `bon_commande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `heure` varchar(255) NOT NULL,
  `client` int(11) DEFAULT NULL,
  `statut` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `bon_commande`
--

INSERT INTO `bon_commande` (`id`, `date`, `heure`, `client`, `statut`) VALUES
(4, '2021-12-11', '16:47:56', 5, 'traitement'),
(5, '2021-12-01', '16:47:50', 5, 'traitement'),
(6, '2021-12-01', '16:47:52', 1, 'traitement'),
(7, '2021-12-01', '17:47:55', 2, 'traitement'),
(8, '2021-12-01', '17:40:03', 5, 'traitement'),
(9, '2021-12-01', '20:35:33', 1, 'traitement'),
(10, '2021-12-06', '13:15:51', 2, 'traitement'),
(11, '2021-12-07', '17:10:06', 5, 'traitement'),
(12, '2021-12-10', '11:23:17', 1, 'traitement');

-- --------------------------------------------------------

--
-- Structure de la table `bon_livraison`
--

DROP TABLE IF EXISTS `bon_livraison`;
CREATE TABLE IF NOT EXISTS `bon_livraison` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `adr_livraison` varchar(255) DEFAULT NULL,
  `bon_commande` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Mode'),
(2, 'Cosmetique'),
(3, 'Textile'),
(4, 'Aliment'),
(5, 'Boisson'),
(9, 'Chaussure'),
(7, 'Confiture et Confiserie'),
(8, 'Interieur'),
(10, 'Confiture'),
(11, 'Meuble'),
(12, 'Decoration'),
(13, 'Art');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `nom_boutique` varchar(255) DEFAULT NULL,
  `pays` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `statut` varchar(255) DEFAULT NULL,
  `tel` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `sex` varchar(5) DEFAULT NULL,
  `dat_naiss` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id`, `nom`, `prenom`, `nom_boutique`, `pays`, `email`, `statut`, `tel`, `password`, `avatar`, `sex`, `dat_naiss`) VALUES
(1, 'KOUASSI', 'KONAN-BOH LOIC EMMANUEL', 'BLK\' Design', NULL, 'admin@gmail.com', 'Super Admin', NULL, '$2y$10$pcfZI1aIAfakgkOTccCdy.RWAlF5RJERi.Mx1QyyYNlDqjjH66v.e', NULL, '0', '1999-01-11'),
(2, 'Da', 'costa Abraham', 'meme', NULL, 'azerty@gmail.com', 'Admin', NULL, '$2y$10$pcfZI1aIAfakgkOTccCdy.RWAlF5RJERi.Mx1QyyYNlDqjjH66v.e', '', NULL, '2000-01-22'),
(3, 'KOUASSI', '88888888888888888888888', 'sdfdsf', NULL, 'k9@gmail.com', 'Super Admin', NULL, '$2y$10$pcfZI1aIAfakgkOTccCdy.RWAlF5RJERi.Mx1QyyYNlDqjjH66v.e', '', 'sex', '2015-05-05'),
(4, 'John', 'Doe', 'So Fresh', NULL, 'autre@gmail.com', 'Super Admin', NULL, '$2y$10$pcfZI1aIAfakgkOTccCdy.RWAlF5RJERi.Mx1QyyYNlDqjjH66v.e', '', NULL, '2000-01-22'),
(5, 'KOUASSI', 'KONAN-BOH LOIC EMMANUEL', 'Web Design', NULL, 'kkble1999@gmail.com', 'Acheteur', NULL, '$2y$10$92G/7n2puJ/yxb7cuJUyJONJTphUsyN4x7wwfz2SGTWOEt.LFkRZe', '', 'male', '2000-01-22'),
(6, 'KOUASSI', 'KONAN-BOH LOIC EMMANUEL', 'KONAN-BOH LOIC EMMANUEL KOUASSI', NULL, 'kkble1sdsq999@gmail.com', 'Admin', NULL, '$2y$10$xYM.ZxlT8QImfcTPtarOWuXcKlRpMxtPdyq4SiSBC4uxfiwIRMTaq', '', 'male', '2000-01-22'),
(7, 'KOUASSI', 'KONAN-BOH LOIC EMMANUEL', 'KONAN-BOH LOIC EMMANUEL KOUASSI', NULL, 'kkble19xwcxccwxcw99@gmail.com', 'Vendeur', NULL, '$2y$10$YUD1p.6PjsNdThVdRypq2.wDjt/Um4YjK0GITIBfWw6AcrkwoCy/.', '', 'male', '2000-01-22'),
(8, 'KOUASSI', 'KONAN-BOH LOIC EMMANUEL', 'KONAN-BOH LOIC EMMANUEL KOUASSI', NULL, 'kkble19&lt;xww&lt;&lt;&lt;&lt;&lt;&lt;&lt;99@gmail.com', 'Vendeur', NULL, '$2y$10$riX6j5iTDs9Gsqnjh7YZZO7FHkBuSe9UA1nYzRqtPowuxs0.yWay6', '', 'male', '2000-01-22'),
(9, 'KOUASSI', 'KONAN-BOH LOIC EMMANUEL', 'KONAN-BOH LOIC EMMANUEL KOUASSI', NULL, 'w&lt;xwx&lt;wxw&lt;kkble1999@gmail.com', 'Vendeur', NULL, '$2y$10$wTTCB7AMqDmYVSGZyROghu75JmyUgnHEhNt95MLjNp.TJCGaT7UGC', '', 'male', '2000-01-22'),
(10, 'KOUASSI', 'KONAN-BOH LOIC EMMANUEL', 'KONAN-BOH LOIC EMMANUEL KOUASSI', NULL, 'kkble1999@gmail.comvcv', 'Vendeur', NULL, '$2y$10$Dz6hI74bdWBRCnC/cEhYHOs1bU9N/5gpCle6oHgn4sy210WD9x4za', '', 'male', '2000-01-22'),
(11, 'KOUASSI', 'KONAN-BOH LOIC EMMANUEL', 'KONAN-BOH LOIC EMMANUEL KOUASSI', NULL, 'kkble1999@gmail.comaaaaaaaaaaaa', 'Admin', NULL, '$2y$10$dpCcMBU/a..2UorQtjeMdOu8.DxDL3ee9gkQUGVQiWR8v.WZvAht6', '', 'male', '2000-01-22'),
(12, 'csqcsdsdsqdqsd', 'dqdsdqsdqsdqqs', 'sdsqdqsdqsddqdqsdqss', NULL, 'qsdsqdqqssqdqsdqqsdqsds', 'Acheteur', NULL, '$2y$10$wD4gHWYBP5kTHjdxIMemL.tqOO.qYHQRe1wfHwQl69ekvP.OMtKs2', '', 'male', '2000-01-22'),
(13, '02222', 'dqsdqsdsqd0', '0sdq0dq0sd0sd0', NULL, 'dsdsqd0sd0qsd0qs0d', 'Acheteur', NULL, '$2y$10$LmVO9OYyslaIzafnGL9i3eHbNv/ihG2c02NCWOEIWTMyOu18jYFFu', '', 'male', '2000-01-22'),
(14, 'ssssssssssssssssss', 'aaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaa', NULL, 'aaaaaaaaaaaaaaaaaaaaaaaaa', 'Acheteur', NULL, '$2y$10$ognwBnMbcDNzw7dceyz6Ken4sver7qztgO1xNxGsDSisSEloo29NK', '', 'male', '2000-01-22'),
(15, 'ssssssssssssssssss', 'aaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaa', NULL, 'aaaaaaaaaaaaaaaaaaaaaaaaadfsdfdf', 'Vendeur', NULL, '$2y$10$UaEO.eO/nvj7E1Au3FoIcu1/wnCjhlfb4BEDmNA9ajdxZTMs/blDu', '', 'male', '2000-01-22'),
(16, 'cxwcwxw', 'vcvxcvxcxwcwcxw', 'aaaaaaaaaaaaaaaaa', NULL, 'aaaaaaaaaaaaaaaaaaaa0', 'Acheteur', NULL, '$2y$10$zlqXgiBGxe2phWMAUYum2u7l2m5bfRv10l3QtTCEpZibNqaBsIozy', '', 'male', '2000-01-22'),
(17, 'KOUASSI', 'KONAN-BOH LOIC EMMANUEL', 'KONAN-BOH LOIC EMMANUEL KOUASSI', NULL, 'kkble1999@gmail.comaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'Acheteur', NULL, '$2y$10$Cpgi.ffz3ex0iBobllFkT.KgnOvHPCN7y9sVvW6VtC5HAbC1UtZ42', '', 'male', '2000-01-22'),
(18, '000000000000000', '000000000000000000000000000', '0000000000000000000000000000000000', NULL, '0000000000000000000000000000000', 'Acheteur', NULL, '$2y$10$6j1oHNrlqfxC3pSvpJ8Dbu7K6Wba2p9ew/qwMRTSrGHmihT/0FIKm', '', 'male', '2000-01-22'),
(19, 'KOUASSI', 'KONAN-BOH LOIC EMMANUEL', 'KONAN-BOH LOIC EMMANUEL KOUASSI', NULL, 'kkbleest-inscrisest-inscrisest-inscrism', 'Acheteur', NULL, '$2y$10$knG3Pl.Vsgsuv9vvNid6Yu3qOQwefk5HXmLtxVZxzOWwb41dF0XhO', '', 'male', '2000-01-22'),
(20, '9999999999999999999999999999', '999999999999999999999999', '99999999999999999999999', NULL, '999999999999999999999', 'Acheteur', NULL, '$2y$10$/npR5C0q9AFiu8sLBplRfe6L4Ox2oniE99lSg4HGLEB6sVJ2PBErq', '', 'male', '2000-01-22'),
(21, '88888888888888888888', '88888888888888888888888', '888888888888888888888', NULL, '88888888888888888888888', 'Acheteur', NULL, '$2y$10$hyxRc3UQSwpWNQTiDnJUkuo2/IXsPM5H.xHLk.4q0fYVErwGNu9Xi', '', 'male', '2000-01-22'),
(22, '88888888888888888888', '88888888888888888888888', '888888888888888888888', NULL, '88888888888888888888888vvvvvvvvvvvvvvvvvvvv', 'Acheteur', NULL, '$2y$10$iyOMPDEKpqcPou6vrAPknuk/FemjFwdzrWoN9KVtQtgxjcsFNWCAq', '', 'male', '2000-01-22'),
(23, 'jbn,bn,nb,nb', 'n,b,nbn,b,nbn,', 'n,b,nb,nb,nbn,', NULL, ',nbnb,b,nbnbn,b,n', 'Acheteur', NULL, '$2y$10$EFxTs/3QM.ykJC0ST7CJoeEWCK3VoHk9k2AIWv9fHm1RT8OHPWd06', '', 'male', '2000-01-22'),
(24, 'ssxw&lt;x&lt;wx', 'xxxxxxxxxxxxxxxxxxxxx', 'KONAN-BOH LOIC EMMANUEL KOUASSI', NULL, '0000000000000000000000000000000000000000000', 'Acheteur', NULL, '$2y$10$lUyHVs2SUO1.msCrJgAmG.WzICi7yAOzsY0cQ0klmwl.xi1kbO0bO', '', 'male', '2000-01-22'),
(25, 'qsqsssssssssssssssssssss', 'aaaaaaaaaaaadddddddddddddd', 'aaaaaaaaaaaaaaa', NULL, 'aaaaaaasssssssssssssssss', 'Vendeur', NULL, '$2y$10$1TiSv4Z/dFuvp8AEKZGmfOm73XkShXFx2VsdH1ZuRRbJUK67JrjjG', '', 'male', '2000-01-22'),
(26, 'mariam', 'joue a la balle', 'mariam shop', NULL, 'mariam.joue@laballe.com', 'Vendeur', NULL, '$2y$10$sgpkfn5.tcwp6JtPtICZWurkAc4rjpBkeBVjZ8x4SLz0QMpRHD29G', '', NULL, NULL),
(27, 'aaaaaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaaaa', NULL, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'Acheteur', NULL, '$2y$10$aEimSKTm3xNDdiYTO5ybD.qibTESAG/HcpqxPZ2z70CyCiC.w/XWW', '', NULL, NULL),
(28, 'President', 'de la republique', 'PresiStore', NULL, 'presi@htag.com', 'Super Admin', NULL, '$2y$10$AWls0TygOzkj6TEfl6gK.OToDjmxo1nYLRNekuZfrn7rLQBV/BWfS', '', '0', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `commander`
--

DROP TABLE IF EXISTS `commander`;
CREATE TABLE IF NOT EXISTS `commander` (
  `product` int(11) DEFAULT NULL,
  `bon_commande` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commander`
--

INSERT INTO `commander` (`product`, `bon_commande`, `quantite`) VALUES
(5, 2, 2),
(7, 2, 1),
(1, 2, 2),
(5, 6, 2),
(7, 6, 1),
(5, 6, 2),
(7, 6, 1),
(5, 6, 2),
(5, 7, 2),
(1, 8, 8),
(8, 9, 1),
(7, 9, 1),
(3, 9, 1),
(3, 10, 1),
(5, 10, 1),
(5, 11, 1),
(18, 11, 1),
(4, 12, 1),
(3, 12, 1),
(13, 12, 1);

-- --------------------------------------------------------

--
-- Structure de la table `langue`
--

DROP TABLE IF EXISTS `langue`;
CREATE TABLE IF NOT EXISTS `langue` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `langue` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `langue`
--

INSERT INTO `langue` (`id`, `langue`) VALUES
(1, 'Français'),
(2, 'Anglais'),
(3, 'Arabe'),
(4, 'Espagnol'),
(5, 'Autres');

-- --------------------------------------------------------

--
-- Structure de la table `pays`
--

DROP TABLE IF EXISTS `pays`;
CREATE TABLE IF NOT EXISTS `pays` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `pays` varchar(255) NOT NULL,
  `Embleme` varchar(255) NOT NULL,
  `Drapeau` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `pays`
--

INSERT INTO `pays` (`id`, `pays`, `Embleme`, `Drapeau`) VALUES
(1, 'Cote d\'ivoire', 'UNION-DIXIPLINE-TRAVAIL', ''),
(2, 'Angola', 'La fuerza-ley-dominacion', ''),
(3, 'Senegal', 'Tchep-wolof-femme', '');

-- --------------------------------------------------------

--
-- Structure de la table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` text NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `price` float DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `category` int(11) DEFAULT NULL,
  `sous_category` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `vue` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `product`
--

INSERT INTO `product` (`id`, `image`, `name`, `description`, `price`, `stock`, `created_at`, `category`, `sous_category`, `status`, `vue`) VALUES
(1, 'images/product/electronic/1.jpg', 'Red Wireless Headphone', 'article par defaut', 2000, 22, '2021-10-24 10:21:22', 5, 1, 0, 1),
(2, 'images/product/electronic/2.jpg', 'Yellow Wireless Headphone', 'description du deuxieme article', 1000, 2, '2021-10-15 00:00:00', 3, 5, 1, 101),
(3, 'images\\product\\electronic/3.jpg', 'Hover Skateboard Scooter', 'ffsdfdfsdfdsf', 5800, 1, '2021-10-12 00:00:36', 3, 3, 1, 20),
(4, 'images/promo/1.png', 'montre co', 'mariam joue à la balle', 25, 1, '2021-10-30 00:00:00', 9, 8, 1, 36),
(5, 'images/promo/2.jpg', 'da mottrt', 'jbnjnccccccccc,', 1, 7000, '2021-10-02 00:00:00', 5, 3, 1, 200),
(6, 'images/promo/31.jpg', 'plolplo', 'plopl', 58, 6, '2021-10-07 00:00:00', 5, 2, 0, 30),
(7, 'images/promo/31.jpg', ',n wx,c ,x c,n ', ' ,n ,n n ,n ', 5, 5, '2021-10-05 00:00:00', 5, 5, 1, 30),
(8, 'images/promo/3.jpg', 'vxcvcv', 'vcvcv', 4, 4, '2021-10-05 00:00:00', 5, 5, 1, 0),
(9, 'images/promo/1.png', 'mariam joue', 'a la balle', 5800, 6, '2021-10-02 00:00:00', 9, 4, 1, 2),
(10, 'images/product/electronic/3.jpg', 'hdjhnbjcbn,', 'hjbhjbbbjb', 5, 2, '2021-10-22 00:00:00', 1, 1, 0, 100),
(11, 'images/product/electronic/4.jpg', 'Hover Red Skateboard Scooter', 'toi mm faut voir', 20500, 2, '2021-10-30 00:00:00', 3, 5, 1, 5),
(12, 'images/product/electronic/5.jpg', 'mariam mange du fouto', 'ah aha ah ah', 150, 0, '2021-10-02 00:00:00', 5, 2, 1, 45),
(13, 'images\\product\\electronic/6.jpg', 'quelque chose', 'sdvn,qsbn,bsnq,', 25, 4, '2021-11-20 13:51:15', 1, 1, 1, 2),
(14, 'images\\product\\electronic/7.jpg', 'montre', 'azertyuiop', 66, 2, '2021-10-15 00:00:00', 2, 5, 0, 82),
(15, 'images\\product\\electronic/11.jpg', 'pokjnbdxgb ', 'olkjnsgb', 700, 0, '2021-10-30 00:00:00', 2, 2, 0, 66),
(16, 'images\\product\\electronic/9.jpg', 'aqzsqzasqe', 'jhvnbyjhv', 600, 3, '2021-10-02 00:00:00', 1, 2, 1, 550),
(17, 'images\\product\\electronic/7.jpg', 'jvhvhwbnbvn', 'vhjvvvh<wvhj', 400, 33, '2021-10-30 00:00:00', 1, 2, 0, 0),
(18, 'images/product/electronic/13.png', 'pknxb ', 'bbbbvnbvb', 1300, 3, '2021-10-30 00:00:00', 1, 5, 1, 666),
(19, 'images/product/electronic/15.jpg', 'pllakolaa', 'bbbbbbb,nb,nbn,b', 9, 9, '2021-10-05 00:00:00', 2, 2, 0, 65),
(20, 'images/product/electronic/16.jpg', 'pmpmploloikuj', 'pxhbbvvvbvbbb', 500, 5, '2021-10-05 00:00:00', 2, 2, 1, 55);

-- --------------------------------------------------------

--
-- Structure de la table `sous_category`
--

DROP TABLE IF EXISTS `sous_category`;
CREATE TABLE IF NOT EXISTS `sous_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `category` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sous_category`
--

INSERT INTO `sous_category` (`id`, `name`, `category`) VALUES
(1, 'Vetement', 1),
(2, 'Chaussure', 5),
(3, 'Accessoire', 6),
(4, 'Savon', 2),
(5, 'Huile', 7),
(6, 'Lait de cheveux', 13),
(7, 'Champoins', 5),
(8, 'Pagne', 8),
(9, 'Sirop', 9),
(10, 'Vin', 1),
(11, 'Epices', 3),
(12, 'Chocolaterie', 4),
(13, 'Biscuits', 6),
(14, 'Laitier', 9),
(15, 'Produit Viviriers', 10),
(16, 'Boisson', 12),
(17, 'Patisserie', 11),
(18, 'Confiture', 4),
(19, 'Meubles', 10),
(20, 'Decoration', 9),
(21, 'Art', 5);

-- --------------------------------------------------------

--
-- Structure de la table `visiteurs`
--

DROP TABLE IF EXISTS `visiteurs`;
CREATE TABLE IF NOT EXISTS `visiteurs` (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `age` mediumint(9) DEFAULT NULL,
  `langue` smallint(9) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `langue` (`langue`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `visiteurs`
--
ALTER TABLE `visiteurs`
  ADD CONSTRAINT `visiteurs_ibfk_1` FOREIGN KEY (`langue`) REFERENCES `langue` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
