<?php
session_start();
require_once '../elements/_header.php';
if(isset($_POST['submit'])){
    if(!empty($_SESSION['panier'])){        
        $_SESSION['commande']=true;        
        header('Location: http://localhost/iska/user/dash-my-order.php');        
    }else{
         echo "error";
    }
    
}

// echo json_encode($json); 




