<?php
    session_start();
    require "../src/include.php";
    verifParams();

    if(isset($_SERVER['PATH_INFO'])){
        $url = trim($_SERVER['PATH_INFO'],'/');
        $url = explode('/',$url);
    }else{
        $url = array("accueil");
    }
    
    $route = array("accueil", "contact","produit","category","Sous_category","details","panier",
                    "supprimer","actionInscription","deconnexion","profil","actionConnexion",
                    "updateProfil","updateAction","validationCommande","pays"  );
    //print_r($url);

    $action = $url[0];
    
    // controller
    if(!in_array($action,$route)){
        $title= "Accueil";
        // $title = "iska-africa - Electronics, Apparel, Computers, Books, DVDs & more";
        $content = "URL introuvable !";
    }else{
        //echo 'Bienvenu sur la page '.$action;
        $function = "display".ucwords($action);
        $title = "Page ".$action; 
        $content = $function();
    }
    // require "include".SP."menu.php";
    $index=true;


?>
<?php 
require_once '../elements/header.php'; 
?>


        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Primary Slider ======-->
            
               <?php require_once "../include/slides.php"; ?>
            
            <!--====== End - Primary Slider ======-->
            
            <?php include('../include/delivery.php'); ?>


            <div class="horizontal-line mt-5 mb-5"></div>

            <!--====== Section 1 ======-->
            <!-- <div class="u-s-p-y-60"> -->

                <!--====== Section Intro ======-->
                <!-- <div class="section__intro u-s-m-b-46">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="section__text-wrap">
                                    <h1 class="section__heading u-c-secondary u-s-m-b-12">SHOP BY DEALS</h1>

                                    <span class="section__span u-c-silver">BROWSE FAVOURITE DEALS</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->
                <!--====== End - Section Intro ======-->


                <!--====== Section Content ======-->
                <!-- <div class="section__content">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 col-md-5 u-s-m-b-30">

                                <a class="collection" href="../shop-side-version-2.php">
                                    <div class="aspect aspect--bg-grey aspect--square">

                                        <<img class="aspect__img" src="../images/product/electronic/1.jpg" alt=""></div>
                                </a></div>
                            <div class="col-lg-7 col-md-7 u-s-m-b-30">

                                <a class="collection" href="../shop-side-version-2.php">
                                    <div class="aspect aspect--bg-grey aspect--1286-890">

                                        <img class="aspect__img collection__img" src="../images/product/electronic/2.jpg" alt=""></div>
                                </a></div>
                            <div class="col-lg-7 col-md-7 u-s-m-b-30">

                                <a class="collection" href="../shop-side-version-2.php">
                                    <div class="aspect aspect--bg-grey aspect--1286-890">

                                        <img class="aspect__img collection__img" src="../images/product/electronic/3.jpg" alt=""></div>
                                </a></div>
                            <div class="col-lg-5 col-md-5 u-s-m-b-30">

                                <a class="collection" href="../shop-side-version-2.php">
                                    <div class="aspect aspect--bg-grey aspect--square">

                                        <img class="aspect__img collection__img" src="../images/product/electronic/4.jpg" alt=""></div>
                                </a></div>
                        </div>
                    </div>
                </div> -->

                <!--====== Section Content ======-->
            <!-- </div> -->
            <!--====== End - Section 1 ======-->


            <!--====== Section 2 ======-->
            
                    
                       <?php include("../include/tendance.php"); ?>
                
            <!--====== End - Section 2 ======-->
            <div class="horizontal-line mt-5 mb-5"></div>
        

            <?php require '../include/affaire_du_jour.php';?> 

            <div class="horizontal-line mt-5 mb-5"></div>

            <?php require '../include/nouvel_arrivage.php';?> 


            <!--====== Section 5 ======-->
           <!-- <div class="banner-bg"> 
                <div class="section__content">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="banner-bg__countdown">
                                    <div class="countdown countdown--style-banner" data-countdown="2020/05/01"></div>
                                </div>
                                <div class="banner-bg__wrap">
                                    <div class="banner-bg__text-1">

                                        <span class="u-c-white">Global</span>

                                        <span class="u-c-secondary">Offers</span></div>
                                    <div class="banner-bg__text-2">

                                        <span class="u-c-secondary">Official Launch</span>

                                        <span class="u-c-white">Don't Miss!</span></div>

                                    <span class="banner-bg__text-block banner-bg__text-3 u-c-secondary">Enjoy Free Shipping when you buy 2 items and above!</span>

                                    <a class="banner-bg__shop-now btn--e-secondary" href="../shop-side-version-2.php">Shop Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>-->
            <!--====== End - Section 5 ======-->
            <div class="horizontal-line mt-5 mb-5"></div>
            <!--====== Section 6 ======-->
            
                <!--====== Section Intro ======-->
              
            <?php include('../include/produit_populaire.php'); ?>
                <!--====== End - Section Content ======-->
            
            <div class="horizontal-line mt-5 mb-5"></div>
            <!--====== End - Section 6 ======-->
            <?php include('../include/autre_slides.php'); ?>

            
            <div class="horizontal-line mt-5 mb-5"></div>
            
                <?php include('../include/promo.php'); ?>   
            
        


        <!--====== Main Footer ======-->
		<?php require_once "../elements/footer.php"; ?>
        