<?php
require_once '../elements/header.php';
$ids = array_keys($_SESSION['panier']);
if(empty($ids)){
    $products = array();
}else{
    $products = $data->query('SELECT * FROM product WHERE id IN ('.implode(',',$ids).')');
}
$total = $panier->total();
// var_dump($_SESSION);
// var_dump($ids);
?>
        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Section 1 ======-->
            <div class="u-s-p-y-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="breadcrumb">
                            <div class="breadcrumb__wrap">
                                <ul class="breadcrumb__list">
                                    <li class="has-separator">

                                        <a href="../page/index.php">Accueil</a></li>
                                    <li class="is-marked">

                                        <a href="cart.php">Panier</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====== End - Section 1 ======-->


            <!--====== Section 2 ======-->
            <div class="u-s-p-b-60">

                <!--====== Section Intro ======-->
                <div class="section__intro u-s-m-b-60">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="section__text-wrap">
                                    <h1 class="section__heading u-c-secondary">PANIER</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Intro ======-->


                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 u-s-m-b-30">
                                <div class="table-responsive">
                                    <table class="table-p">
                                        <tbody>
                                            <?php foreach($products as $k => $product) : ?>
                                            <?php $category = $data->name_category($product['category']); ?>
                                            <!--====== Row ======-->
                                            <tr>
                                                <td>
                                                    <div class="table-p__box">
                                                        <div class="table-p__img-wrap">

                                                            <img class="u-img-fluid" src="../<?= $product['image']; ?>" alt="<?= $product['name']; ?>"></div>
                                                        <div class="table-p__info">

                                                            <span class="table-p__name">

                                                                <a href="../product/content.php?id=<?=$product['id']?>"><?= $product['name']; ?> </a></span>

                                                            <span class="table-p__category">

                                                                <a href="../product/category.php?id=<?=$product['id']?>"><?= $category[0]['name'] ?></a></span>
                                                            <ul class="table-p__variant-list">
                                                                <li>

                                                                    <span>Taille: 22</span></li>
                                                                <li>

                                                                    <span>Couleur: Unique</span></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>

                                                    <span class="table-p__price"><?= $product['price']; ?> F</span></td>
                                                <td>
                                                    <div class="table-p__input-counter-wrap">

                                                        <!--====== Input Counter ======-->
                                                        <div class="input-counter">

                                                            <span class="input-counter__minus fas fa-minus"></span>

                                                            <input class="input-counter__text input-counter--text-primary-style" type="text" value="<?= $_SESSION['panier'][$product['id']] ?>" data-min="1" data-max="1000">

                                                            <span class="input-counter__plus fas fa-plus"></span></div>
                                                        <!--====== End - Input Counter ======-->
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="table-p__del-wrap">

                                                        <a class="far fa-trash-alt table-p__delete-link" href="cart.php?delPanier=<?= $product['id']; ?>"></a></div>
                                                </td>
                                            </tr>
                                            <!--====== End - Row ======-->
                                            <?php endforeach; ?>

                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="route-box">
                                    <div class="route-box__g1">

                                        <a class="route-box__link" href="javascript:history.back()"><i class="fas fa-long-arrow-alt-left"></i>

                                            <span>CONTINUER VOS ACHATS</span></a></div>
                                    <div class="route-box__g2">

                                        <a class="route-box__link" href="cart.php"><i class="fas fa-trash"></i>

                                            <span>VIDER LE PANIER</span></a>

                                        <a class="route-box__link" href="cart.php"><i class="fas fa-sync"></i>

                                            <span>MISE À JOUR PANIER</span></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 2 ======-->


            <!--====== Section 3 ======-->
            <div class="u-s-p-b-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 u-s-m-b-30">
                                <form action="addcommande.php" method="post" class="f-cart">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 u-s-m-b-30">
                                            <div class="f-cart__pad-box">
                                                <h1 class="gl-h1">ESTIMATION DE LIVRAISON ET TAXES</h1>

                                                <span class="gl-text u-s-m-b-30">Entrez votre destination pour obtenir une estimation d'expédition.</span>
                                                <div class="u-s-m-b-30">

                                                    <!--====== Select Box ======-->

                                                    <label class="gl-label" for="shipping-country">PAYS *</label>
                                                    <select class="select-box select-box--primary-style" name="shipping-country">
                                                        <option value="">Choisissez un pays</option>
                                                        <option value="uae">Émirats arabes unis (EAU)</option>
                                                        <option value="uk">Royaume-Uni (Royaume-Uni)</option>
                                                        <option value="us">États-Unis (États-Unis)</option>
                                                    </select>
                                                    <!--====== End - Select Box ======-->
                                                </div>
                                                <div class="u-s-m-b-30">

                                                    <!--====== Select Box ======-->

                                                    <label class="gl-label" for="shipping-state">ETAT/PROVINCE *</label>
                                                    <select class="select-box select-box--primary-style" name="shipping-state">
                                                        <option value="">Choisissez État/Province</option>
                                                        <option value="al">Alabama</option>
                                                        <option value="al">Alaska</option>
                                                        <option value="ny">New York</option>
                                                    </select>
                                                    <!--====== End - Select Box ======-->
                                                </div>
                                                <div class="u-s-m-b-30">

                                                    <label class="gl-label" for="shipping-zip">ZIP / CODE POSTAL *</label>

                                                    <input class="input-text input-text--primary-style" type="text" name="shipping-zip" placeholder="Zip/Postal Code"></div>
                                                <div class="u-s-m-b-30">

                                                    <a class="f-cart__ship-link btn--e-transparent-brand-b-2" href="cart.php">CALCULER FRAIS DE PORT</a></div>

                                                <span class="gl-text">Remarque : Dans certains pays, la livraison gratuite est disponible, sinon nos frais forfaitaires ou les frais de livraison par pays s'appliqueront.</span>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-6 u-s-m-b-30">
                                            <div class="f-cart__pad-box">
                                                <h1 class="gl-h1">REMARQUE</h1>

                                                <span class="gl-text u-s-m-b-30">Ajouter une note spéciale sur votre produit</span>
                                                <div>

                                                    <label for="f-cart-note"></label><textarea class="text-area text-area--primary-style" id="f-cart-note"></textarea></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-6 u-s-m-b-30">
                                            <div class="f-cart__pad-box">
                                                <div class="u-s-m-b-30">
                                                    <table class="f-cart__table">
                                                        <tbody>
                                                            <tr>
                                                                <td>EXPÉDITION</td>
                                                                <td>1000 F</td>
                                                            </tr>
                                                            <tr>
                                                                <td>IMPÔT</td>
                                                                <td>0 F</td>
                                                            </tr>
                                                            <tr>
                                                                <td>TOTAL </td>
                                                                <td><?= number_format($total, 2, ',',' '); ?> F</td>
                                                            </tr>
                                                            <tr>
                                                                <td>GRAND TOTAL</td>
                                                                <td><?= number_format($total*1.18, 2, ',',' '); ?> F</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div>

                                                    <button class="btn btn--e-brand-b-2"  name="submit"> PASSER À LA CAISSE</button></div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 3 ======-->
        </div>
        <!--====== End - App Content ======-->


        <?php
require_once '../elements/footer.php';
?>