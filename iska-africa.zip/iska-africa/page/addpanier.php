<?php
session_start();
require_once '../elements/_header.php';
$json = array('error' => true);
if(isset($_GET['id'])){
    $product = $data->query('SELECT id FROM product WHERE id= :id',array('id' =>$_GET['id']));
    if(empty($product)){
        $json['message'] ="ce produit n'existe pas";
    }
    $json['error']= false;
    $json['total'] = $panier->total();
    $json['count'] = $panier->count();
    $json['countL'] = $panier->count() +1;
    $panier->add($product[0]['id']);
    // bouton retour en arriere <a href="javascript:history.back()">retourner sur le catalogue</a>
}
// j'ai commenté la ligne suivante pour ne pas afficher l'alert
echo json_encode($json); 




