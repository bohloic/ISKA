<?php
function connected():bool{
    if(session_status() === PHP_SESSION_NONE){
        session_start();
    }
    return !empty( $_SESSION['connecte']);
}

function force_user():void{
    if(!connected()){
        header('Location: /iska/user/signin.php');
        exit;
    }
}

function connection() {
    if(connected()){
        // header('Location: /login.php');
        // Récupérer le code de réponse par défaut
var_dump(http_response_code());

// Définir un code de réponse
http_response_code(404);

// Récupérer le nouveau code de réponse
var_dump(http_response_code());
// header('Location: /iska/user/login.php');
require 'login.php';
    }
}





