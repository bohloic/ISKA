<?php
$atts = [
    'nomEtu', 
    'preEtu', 
    'adrEtu', 
    'contEtu'
];
$champs= [
    'nomEtu' => 'Nom',
    'preEtu' => 'Prenom',
    'nomClass' => 'Classe',
    'adrEtu' => 'Adresse',
    'contEtu' => 'Contact'
];


$typAbn=[
    1 => 'Jour',
    2 => 'Semaine',
    3 => 'Mois'
];


