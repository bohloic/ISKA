<?php

//menu
function nav_item (string $lien, string $titre, string $linkclass): string {
    $classe ='nav-item';
    if($_SERVER['SCRIPT_NAME'] === $lien ){
        $classe .= '  active';
    } 
    return ' 
    <li  class="'. $classe .'">
        <a class="'.$linkclass.'" href="'. $lien .'">'.  $titre.'</a>        
    </li>';
    
}
function nav_menu(string $linkclass=''): string {
    return
    nav_item('/iska/user/dashboard.php', 'Compte', $linkclass) .
    nav_item('', 'Pays', $linkclass.' dropdown') .
    nav_item('/iska/page/cart.php', 'Panier', $linkclass);
}
//dashboard menu
function nav_dash (string $lien, string $titre, string $linkclass): string {
    $classe ='dash';
    if($_SERVER['SCRIPT_NAME'] === $lien ){
        $classe .= '-active';
    } 
    return ' 
    <li  class="'. $classe .'">
        <a class="'.$linkclass.'" href="'. $lien .'">'.  $titre.'</a>        
    </li>';
    
}
function dash_menu(string $linkclass=''): string {
    return
    nav_dash('/iska/user/dashboard.php', 'Gérer mon compte', $linkclass) .
    nav_dash('/iska/user/dash-my-profile.php', 'Mon profil', $linkclass) .
    nav_dash('/iska/user/dash-address-book.php', "Carnet d'adresses", $linkclass) .
    nav_dash('/iska/user/dash-track-order.php', 'Suivi de commande', $linkclass) .
    nav_dash('/iska/user/dash-my-order.php', 'Mes commandes', $linkclass) .
    nav_dash('/iska/user/dash-payment-option.php', 'Mes options de paiement', $linkclass) .
    nav_dash('/iska/user/dash-cancellation.php', 'Mes retours et annulations', $linkclass) .
    nav_dash('/iska/user/logout.php', 'Déconnexion', $linkclass);
 }

 
 


function checkbox(string  $name, string $value , array $data):string
{
    $attributes='';
    if (isset($data[$name]) && in_array($value, $_GET[$name])){
        $attributes .= 'checked';
    };
    return <<<HTML
    <input type="checkbox" name="{$name}[]" value="$value" $attributes > 

HTML;   
}

function radio(string  $name, string $value , array $data):string
{
    $attributes='';
    if (isset($data[$name]) && ($value === $_GET[$name])){
        $attributes .= 'checked';
    };
    return <<<HTML
    <input type="radio" name="{$name}" value="$value" $attributes > 

HTML;   
}

function creneaux_html( array $creneaux)
{
    if(count($creneaux) === 0){
        return 'fermé';
    };
    $phrases= [];    
    foreach ($creneaux as $creneau) {
        $phrases[] = "de <b>{$creneau[0]}h </b> à <b>{$creneau[1]}h </b> " ;
    };
    return 'Ouvert  '. implode(' et ', $phrases);

}



?>